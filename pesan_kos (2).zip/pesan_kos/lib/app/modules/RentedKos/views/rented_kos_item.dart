import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pesan_kos/app/modules/RentedKos/controllers/rented_kos_controller.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

class RentedKosItem extends GetView<RentedKosController> {
  const RentedKosItem({super.key});

  @override
  Widget build(BuildContext context) {
    return controller.obx(
      (daftarKos) => Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            ...controller.daftarKos
                .map(
                  (kos) => Column(
                    children: [
                      ListTile(
                        leading: CircleAvatar(
                          backgroundImage:
                              CachedNetworkImageProvider(kos.image[0]),
                        ),
                        title: Text(kos.kosName),
                        subtitle: Text("kamar tersedia: ${kos.availableRoom}"),
                        trailing: Icon(Icons.open_in_new_rounded),
                        onTap: () {
                          Get.toNamed(Routes.DETAIL_KOS, arguments: kos);
                        },
                      ),
                      Divider(),
                    ],
                  ),
                )
                .toList()
          ],
        ),
      ),
      onEmpty: Center(
        child: Text("Belum ada kos yang disewakan"),
      ),
    );
  }
}
