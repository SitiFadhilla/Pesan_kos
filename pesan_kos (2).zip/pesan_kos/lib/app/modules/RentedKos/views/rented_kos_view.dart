import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/RentedKos/views/rented_kos_item.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

import '../controllers/rented_kos_controller.dart';

class RentedKosView extends GetView<RentedKosController> {
  const RentedKosView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: ReusableWidget.customAppBar("Rented Kos", actions: [
        IconButton(
            onPressed: () => Get.toNamed(Routes.RENTER),
            icon: Icon(Icons.group))
      ]),
      body: const Center(
        child: RentedKosItem(),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Get.toNamed(Routes.POST_KOS);
        },
        child: Icon(
          Icons.add,
          color: Colors.white,
        ),
        backgroundColor: ReusableWidget.summerPrimary,
      ),
    );
  }
}
