import 'package:get/get.dart';
import 'package:pesan_kos/app/controllers/auth_controller.dart';
import 'package:pesan_kos/app/controllers/firestore_controller.dart';
import 'package:pesan_kos/app/controllers/user_model_controller.dart';
import 'package:pesan_kos/app/data/model/kosModel.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';

class RentedKosController extends GetxController
    with StateMixin<List<KosModel>> {
  final authC = AuthController.instance;
  final dataC = FirestoreController.instance;
  final userC = UserModelController.instance;

  UserModel get user => userC.userModel.value!;

  RxList<KosModel> daftarKos = RxList.empty();

  final count = 0.obs;
  @override
  void onInit() {
    daftarKos.bindStream(
      dataC.readMyKos(id: authC.currentUser.value!.uid).asyncMap(
        (event) {
          if (event.isNotEmpty) {
            change(event, status: RxStatus.success());
          } else {
            change(event, status: RxStatus.empty());
          }
          return event;
        },
      ),
    );
    super.onInit();
  }
}
