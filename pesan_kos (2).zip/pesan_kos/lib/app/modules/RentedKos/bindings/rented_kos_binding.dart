import 'package:get/get.dart';

import '../controllers/rented_kos_controller.dart';

class RentedKosBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<RentedKosController>(
      () => RentedKosController(),
    );
  }
}
