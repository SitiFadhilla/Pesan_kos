import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pesan_kos/app/data/model/kosModel.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/home/controllers/home_controller.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

class HomeItem extends GetView<HomeController> {
  const HomeItem({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Obx(
        () => Row(
          children: List.generate(
            controller.daftarKos.length,
            (index) {
              KosModel model = controller.daftarKos[index];
              return ReusableWidget.kosCard(
                status: controller.user.status,
                favOnTap: () {},
                model: model,
                onTap: () {
                  Get.toNamed(Routes.DETAIL_KOS, arguments: model);
                },
              );
            },
          ),
        ),
      ),
    );
  }
}
