import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:pesan_kos/app/controllers/user_model_controller.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/home/views/home_item.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

import '../controllers/home_controller.dart';

class HomeView extends GetView<HomeController> {
  HomeView({Key? key}) : super(key: key);

  // Depedency for global, after login or register
  final userC = Get.put(UserModelController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: ReusableWidget.customAppBar(
        "Beranda",
        actions: [
          IconButton(
              onPressed: () {
                showSearch(
                  context: context,
                  delegate: CustomSearchDelegate(kost: controller.daftarKos),
                );
              },
              icon: Icon(
                Icons.search,
                color: Get.iconColor,
              )),
          IconButton(
            onPressed: () {
              Get.toNamed(Routes.CHAT_LIST);
            },
            icon: Icon(
              Icons.chat_bubble_outline,
              color: Get.iconColor,
            ),
          ),
          IconButton(
            onPressed: () {
              Get.toNamed(Routes.PROFILE);
            },
            icon: Icon(
              Icons.person,
              color: Get.iconColor,
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 20,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 8.0),
                child: Text(
                  "Choose and\nStay",
                  style: TextStyle(
                      color: ReusableWidget.summerPrimary,
                      fontWeight: FontWeight.bold,
                      fontSize: 25),
                ),
              ),
              HomeItem(),
              Padding(
                padding: const EdgeInsets.only(left: 8.0),
                child: Text(
                  "You may like",
                  style: TextStyle(
                      color: ReusableWidget.summerPrimary,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
              ),
              HomeItem(),
            ],
          ),
        ),
      ),
    );
  }
}
