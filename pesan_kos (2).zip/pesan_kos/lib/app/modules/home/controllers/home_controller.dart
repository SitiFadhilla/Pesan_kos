import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pesan_kos/app/controllers/firestore_controller.dart';
import 'package:pesan_kos/app/controllers/user_model_controller.dart';
import 'package:pesan_kos/app/data/model/kosModel.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

class HomeController extends GetxController {
  final dataC = FirestoreController.instance;
  final userC = UserModelController.instance;

  UserModel get user => userC.userModel.value!;

  RxList<KosModel> daftarKos = RxList.empty();

  @override
  void onInit() {
    daftarKos.bindStream(dataC.readAllKos());

    super.onInit();
  }
}

class CustomSearchDelegate extends SearchDelegate {
  CustomSearchDelegate({required this.kost});
  final dataC = FirestoreController.instance;
  List<KosModel> kost;
  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        onPressed: () {
          query = "";
        },
        icon: Icon(Icons.clear),
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
        onPressed: () {
          Get.back();
        },
        icon: Icon(Icons.arrow_back));
  }

  @override
  Widget buildResults(BuildContext context) {
    List<KosModel> daftarKos = [];
    kost.forEach(
      (element) {
        if (element.kosName.toLowerCase().contains(query.toLowerCase()) ||
            element.location.toLowerCase().contains(query.toLowerCase())) {
          daftarKos.add(element);
        }
      },
    );
    return (daftarKos.length > 0)
        ? Column(
            children: [
              ...daftarKos
                  .map(
                    (model) => ListTile(
                      onTap: () {
                        Get.toNamed(Routes.DETAIL_KOS, arguments: model);
                      },
                      leading: CircleAvatar(
                        backgroundImage:
                            CachedNetworkImageProvider(model.image[0]),
                      ),
                      title: Text(model.kosName),
                      subtitle: Text(model.location),
                    ),
                  )
                  .toList(),
            ],
          )
        : Center(
            child: Text("Kos tidak ditemukan"),
          );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    List<KosModel> daftarKos = [];
    kost.forEach(
      (element) {
        if (element.kosName.toLowerCase().contains(query.toLowerCase()) ||
            element.location.toLowerCase().contains(query.toLowerCase())) {
          daftarKos.add(element);
        }
      },
    );
    return (daftarKos.length > 0)
        ? Column(
            children: [
              ...daftarKos
                  .map(
                    (model) => ListTile(
                      onTap: () {
                        Get.toNamed(Routes.DETAIL_KOS, arguments: model);
                      },
                      leading: CircleAvatar(
                        backgroundImage:
                            CachedNetworkImageProvider(model.image[0]),
                      ),
                      title: Text(model.kosName),
                      subtitle: Text(model.location),
                    ),
                  )
                  .toList(),
            ],
          )
        : Center(
            child: Text("Kos tidak ditemukan"),
          );
  }
}
