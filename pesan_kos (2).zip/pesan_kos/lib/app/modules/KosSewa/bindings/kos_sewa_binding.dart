import 'package:get/get.dart';

import '../controllers/kos_sewa_controller.dart';

class KosSewaBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<KosSewaController>(
      () => KosSewaController(),
    );
  }
}
