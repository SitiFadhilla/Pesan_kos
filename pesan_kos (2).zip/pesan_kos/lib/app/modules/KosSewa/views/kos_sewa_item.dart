import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:pesan_kos/app/data/model/bookModel.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/KosSewa/controllers/kos_sewa_controller.dart';

class KosSewaItem extends GetView<KosSewaController> {
  const KosSewaItem({super.key});

  @override
  Widget build(BuildContext context) {
    return controller.obx(
      (daftarBook) => ListView.separated(
        itemCount: daftarBook!.length,
        separatorBuilder: (context, index) => SizedBox(
          height: 16,
        ),
        itemBuilder: (context, index) {
          BookModel model = daftarBook[index];
          return buildCardItem(model: model);
        },
      ),
    );
  }

  Widget buildCardItem({required BookModel model}) {
    return Card(
      clipBehavior: Clip.antiAliasWithSaveLayer,
      child: Column(
        children: [
          ListTile(
            title: Text(model.kosName),
            subtitle: Text("nama kos"),
            leading: Icon(Icons.person),
          ),
          ListTile(
            title: Text("${model.bookDuration} bulan"),
            subtitle: Text("durasi sewa"),
            leading: Icon(Icons.apartment),
          ),
          ListTile(
            title: Text(
                "${NumberFormat.currency(locale: "id_ID", name: "ID", symbol: "IDR").format(model.price)}"),
            subtitle: Text("total pembayaran"),
            leading: Icon(Icons.money),
          ),
          ListTile(
            onTap: () async {
              controller.dataC.printPaymentPDF(model);
            },
            tileColor: ReusableWidget.summerPrimary,
            title: Text(
              "Cetak incvoice",
              style: TextStyle(color: Colors.white),
            ),
            subtitle: Text(
              "total pembayaran",
              style: TextStyle(color: Colors.white),
            ),
            leading: Icon(Icons.receipt, color: Colors.white),
          ),
        ],
      ),
    );
  }
}
