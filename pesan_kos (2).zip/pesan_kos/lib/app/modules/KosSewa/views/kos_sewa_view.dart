import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/KosSewa/views/kos_sewa_item.dart';

import '../controllers/kos_sewa_controller.dart';

class KosSewaView extends GetView<KosSewaController> {
  const KosSewaView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: ReusableWidget.customAppBar("Kos yang disewa"),
      body: const Center(
        child: Padding(
          padding: EdgeInsets.all(8.0),
          child: KosSewaItem(),
        ),
      ),
    );
  }
}
