import 'package:get/get.dart';
import 'package:pesan_kos/app/controllers/firestore_controller.dart';
import 'package:pesan_kos/app/controllers/user_model_controller.dart';
import 'package:pesan_kos/app/data/model/bookModel.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';

class KosSewaController extends GetxController
    with StateMixin<List<BookModel>> {
  final userC = UserModelController.instance;
  final dataC = FirestoreController.instance;

  UserModel get user => userC.userModel.value!;
  RxList<BookModel> daftarBook = RxList();
  @override
  void onInit() {
    daftarBook.bindStream(dataC.readBookedKos(id: user.id).asyncMap((booked) {
      if (booked.length == 0) {
        change(booked, status: RxStatus.empty());
      } else {
        change(booked, status: RxStatus.success());
      }
      return booked;
    }));
    super.onInit();
  }
}
