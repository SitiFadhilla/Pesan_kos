import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:pesan_kos/app/data/model/chatRoomModel.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

import '../controllers/chat_list_controller.dart';

class ChatListView extends GetView<ChatListController> {
  const ChatListView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Daftar obrolan'),
        ),
        body: controller.obx(
          (state) => buildBodyRoom(rooms: state!),
        ));
  }

  Widget buildBodyRoom({required List<ChatRoom> rooms}) {
    return ListView(
        children: rooms.map((room) {
      if (room.id.contains(controller.userMap.id)) {
        return ListTile(
          onTap: () => Get.toNamed(Routes.CHAT_ROOM, arguments: room),
          title: (room.creatorId == controller.userMap.id)
              ? Text(room.targetRoomName)
              : Text(room.roomName),
          leading: Icon(Icons.chat_bubble_outline),
        );
      }
      return SizedBox();
    }).toList());
  }
}
