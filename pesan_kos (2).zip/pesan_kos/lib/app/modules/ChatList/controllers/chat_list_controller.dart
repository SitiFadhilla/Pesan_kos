import 'package:get/get.dart';
import 'package:pesan_kos/app/controllers/auth_controller.dart';
import 'package:pesan_kos/app/controllers/firestore_controller.dart';
import 'package:pesan_kos/app/controllers/storage_controller.dart';
import 'package:pesan_kos/app/controllers/user_model_controller.dart';
import 'package:pesan_kos/app/data/model/chatRoomModel.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';

class ChatListController extends GetxController
    with StateMixin<List<ChatRoom>> {
  final authC = AuthController.instance;
  final dataC = FirestoreController.instance;
  final storageC = StorageController.instance;
  final userC = UserModelController.instance;

  RxList<ChatRoom> rooms = RxList<ChatRoom>.empty();
  UserModel get userMap => userC.userModel.value!;

  @override
  void onInit() {
    rooms.bindStream(dataC.streamChatRoom().asyncMap((event) {
      change(event, status: RxStatus.success());
      return event;
    }));
    super.onInit();
  }
}
