import 'package:firebase_core/firebase_core.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:pesan_kos/app/controllers/auth_controller.dart';
import 'package:pesan_kos/app/controllers/firestore_controller.dart';
import 'package:pesan_kos/app/data/model/dialogModel.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';
import 'package:pesan_kos/app/modules/SignUp/views/sign_up_first.dart';
import 'package:pesan_kos/app/modules/SignUp/views/sign_up_page_third.dart';
import 'package:pesan_kos/app/modules/SignUp/views/sign_up_second.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

enum Gender { MALE, FEMALE }

enum Status { USER, OWNER }

class SignUpController extends GetxController {
  // memanggil depedency
  final authC = AuthController.instance;
  final dataC = FirestoreController.instance;

  // FormKey Section
  final List<GlobalKey<FormState>> formKey = [
    GlobalKey<FormState>(),
    GlobalKey<FormState>(),
  ];

  // Token agar bisa menerima notification
  Rxn<String> token = Rxn();

  //Radio Button value untuk Jenis Kelamin dan Tipe Akun
  var selectedGender = Gender.MALE.name.obs;
  List<String> genders = Gender.values.map((e) => e.name).toList();

  var selectedStatus = Status.USER.name.obs;
  List<String> statuses = Status.values.map((e) => e.name).toList();

  // Text Controllers
  var emailController = TextEditingController();
  var passController = TextEditingController();

  var pekerjaanController = TextEditingController();

  var nameController = TextEditingController();
  var currenBirthDate = DateTime.now().obs;

  // Validating Input user
  String? validateEmail(String? value, String error) {
    if (value!.isEmpty || !GetUtils.isEmail(value)) {
      return error;
    } else {
      return null;
    }
  }

  String? validateName(String? value, String error) {
    if (value!.isEmpty || !RegExp(r'^[a-z A-Z]+$').hasMatch(value)) {
      return error;
    } else {
      return null;
    }
  }

  String? validatePassword(String? value, String error) {
    if (value!.isEmpty || value.length < 8) {
      return (value.isEmpty) ? error : "at least 8 character";
    } else {
      return null;
    }
  }

  // Create User
  Future registerUser() async {
    try {
      if (await Permission.notification.isGranted) {
        await authC
            .signUpUser(
                email: emailController.text, password: passController.text)
            .then(
          (value) async {
            UserModel model = UserModel(
                id: value!.user!.uid,
                email: emailController.text,
                name: nameController.text,
                image: null,
                status: selectedStatus.value,
                token: token.value!,
                jenisKelamin: selectedGender.value,
                pekerjaan: pekerjaanController.text);
            await dataC.createUser(id: model.id, model: model);
          },
        );
      } else {
        openAppSettings();
      }
    } on FirebaseException catch (error) {
      if (error.code == "email-already-in-use") {
        DialogModel.ErrorDialog("Email sudah digunakan");
      } else if (error.code == "weak-password") {
        DialogModel.ErrorDialog("Password lemah");
      }
    }
  }

  // Stepper Section

  var stepIndex = 0.obs;

  List<Step> signUpStep = const [
    Step(title: Text("Email & Password"), content: SignUpFirstPage()),
    Step(title: Text("Nama dan Pekerjaan"), content: SignUpSecondPage()),
    Step(title: Text("Gender and Akun"), content: SignUpThirdPage()),
  ];

  void nextStep() async {
    if (stepIndex.value != 2) {
      if (formKey[stepIndex.value].currentState!.validate()) {
        stepIndex.value += 1;
      }
    } else {
      DialogModel.ConfirmationDialog(
        title: "Konfirmasi",
        middleText: "yakin data sudah benar?",
        confirmation: () async {
          await registerUser().whenComplete(() => Get.offAllNamed(Routes.HOME));
        },
      );
    }
  }

  void previousStep() {
    if (stepIndex.value > 0) {
      stepIndex.value -= 1;
    }
  }

  void onTapped(int index) {
    if (stepIndex.value != 2) {
      if (formKey[stepIndex.value].currentState!.validate()) {
        stepIndex.value = index;
      }
    } else {
      stepIndex.value = index;
    }
  }

  @override
  void onInit() async {
    token.value = await FirebaseMessaging.instance.getToken();
    super.onInit();
  }
}
