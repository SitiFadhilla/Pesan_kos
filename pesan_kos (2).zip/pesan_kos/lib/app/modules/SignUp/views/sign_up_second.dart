import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pesan_kos/app/modules/SignUp/controllers/sign_up_controller.dart';
import 'package:pesan_kos/app/data/reusable.dart';

class SignUpSecondPage extends GetView<SignUpController> {
  const SignUpSecondPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Form(
        key: controller.formKey[1],
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // NAME FIELD
                ReusableWidget.customWidget(
                  padding: 10,
                  child: ReusableWidget.customTextFormField(
                    isObscured: RxBool(false),
                    hint: "enter name",
                    label: "name",
                    inputType: TextInputType.name,
                    textEditingController: controller.nameController,
                    validator: (value) {
                      return controller.validateName(
                          value, "your name contain symbol?");
                    },
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                // PEKERJAAN FIELD
                ReusableWidget.customWidget(
                  padding: 10,
                  child: ReusableWidget.customTextFormField(
                    isObscured: RxBool(false),
                    hint: "pekerjaan",
                    label: "jenis pekerjaan (mahasiswa bisa)",
                    inputType: TextInputType.name,
                    textEditingController: controller.pekerjaanController,
                    validator: (value) {
                      return controller.validateName(value, "please fill id");
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
