import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pesan_kos/app/modules/SignUp/controllers/sign_up_controller.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:intl/intl.dart';

class SignUpThirdPage extends GetView<SignUpController> {
  const SignUpThirdPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Form(
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Jenis Kelamin Radio
              ReusableWidget.customWidget(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ReusableWidget.customWidget(
                      child: Text(
                        "Jenis Kelamin",
                        style: Get.textTheme.bodyLarge,
                      ),
                    ),
                    ...controller.genders.map(
                      (String gender) => Obx(
                        () => ListTile(
                          leading: Radio(
                            value: gender,
                            groupValue: controller.selectedGender.value,
                            onChanged: (value) =>
                                controller.selectedGender.value = value!,
                          ),
                          title: Text(gender),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 20,
              ),
              // Tipe Akun Radio
              ReusableWidget.customWidget(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ReusableWidget.customWidget(
                      child: Text(
                        "Tipe akun",
                        style: Get.textTheme.bodyLarge,
                      ),
                    ),
                    ...controller.statuses.map(
                      (String status) => Obx(
                        () => ListTile(
                          leading: Radio(
                            value: status,
                            groupValue: controller.selectedStatus.value,
                            onChanged: (value) =>
                                controller.selectedStatus.value = value!,
                          ),
                          title: Text(status),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
