import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../controllers/sign_up_controller.dart';

class SignUpView extends GetView<SignUpController> {
  const SignUpView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SignUpView'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Obx(
              () => Stepper(
                type: StepperType.vertical,
                steps: controller.signUpStep,
                currentStep: controller.stepIndex.value,
                onStepCancel: () => controller.previousStep(),
                onStepContinue: () => controller.nextStep(),
                onStepTapped: (value) => controller.onTapped(value),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
