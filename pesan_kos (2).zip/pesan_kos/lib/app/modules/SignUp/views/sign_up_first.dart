import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/SignUp/controllers/sign_up_controller.dart';

class SignUpFirstPage extends GetView<SignUpController> {
  const SignUpFirstPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Form(
        key: controller.formKey[0],
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // EMAIL FIELD
                ReusableWidget.customWidget(
                  padding: 10,
                  child: ReusableWidget.customTextFormField(
                    isObscured: RxBool(false),
                    hint: "enter email",
                    label: "email",
                    inputType: TextInputType.emailAddress,
                    textEditingController: controller.emailController,
                    validator: (value) {
                      return controller.validateEmail(value, "email invalid");
                    },
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                // PASSWORD FIELD
                ReusableWidget.customWidget(
                  padding: 10,
                  child: ReusableWidget.customTextFormField(
                    enableIcon: true,
                    isObscured: RxBool(true),
                    hint: "enter password",
                    label: "password",
                    inputType: TextInputType.emailAddress,
                    textEditingController: controller.passController,
                    validator: (value) {
                      return controller.validatePassword(
                          value, "please enter password");
                    },
                  ),
                ),
                SizedBox(
                  height: 30,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
