import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:get/get.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/DetailKos/controllers/detail_kos_controller.dart';

class DetailImage extends GetView<DetailKosController> {
  const DetailImage({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CarouselSlider(
          items: controller.kosModel.image.map((url) {
            return Container(
              decoration: BoxDecoration(
                  image: DecorationImage(
                image: CachedNetworkImageProvider(url),
              )),
            );
          }).toList(),
          options: CarouselOptions(
            onPageChanged: (index, reason) =>
                controller.imageIndex.value = index,
            viewportFraction: 0.8,
            initialPage: 0,
            reverse: false,
            enableInfiniteScroll: false,
            enlargeCenterPage: true,
            enlargeFactor: 1,
            scrollDirection: Axis.horizontal,
          ),
        ),
        Obx(
          () => Align(
            alignment: Alignment.bottomCenter,
            child: DotsIndicator(
              decorator: DotsDecorator(
                  color: Colors.grey,
                  spacing: EdgeInsets.all(3),
                  activeColor: ReusableWidget.summerPrimary),
              dotsCount: controller.kosModel.image.length,
              position: controller.imageIndex.value,
            ),
          ),
        ),
      ],
    );
  }
}
