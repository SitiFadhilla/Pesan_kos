import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/DetailKos/controllers/detail_kos_controller.dart';
import 'package:pesan_kos/app/modules/PostKos/views/post_kos_edit.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

class DetailInfo extends GetView<DetailKosController> {
  const DetailInfo({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              "${NumberFormat.currency(locale: "id_ID", name: "ID", symbol: "IDR").format(controller.kosModel.price)}/Bulan",
              style: ReusableWidget.priceStyle(),
            ),
            Spacer(),
            if (controller.kosModel.ownerId != (controller.userModel.id))
              IconButton(
                onPressed: () {
                  controller.createChatRoom(
                      userId: controller.userModel.id,
                      targetId: controller.kosModel.ownerId,
                      roomName: controller.userModel.name!,
                      users: controller.userModel);
                },
                icon: Icon(Icons.chat_bubble_outline),
              ),
            (controller.kosModel.ownerId !=
                    (controller.authC.currentUser.value?.uid ?? ''))
                ? IconButton(
                    onPressed: () async {
                      if (controller.favIsExist == true) {
                        controller.dataC.deleteKosFavourite(
                            kosId: controller.kosModel.id,
                            userId: controller.userModel.id);
                        controller.favIsExist.value = false;
                      } else {
                        controller.dataC.addKosFavourite(
                            KosId: controller.kosModel.id,
                            userId: controller.userModel.id,
                            kos: controller.kosModel);
                        controller.favIsExist.value = true;
                      }
                    },
                    icon: Obx(
                      () => Icon((controller.favIsExist.value)
                          ? Icons.bookmark
                          : Icons.bookmark_outline),
                    ),
                  )
                : Row(
                    children: [
                      IconButton(
                        icon: Icon(Icons.edit_outlined),
                        onPressed: () {
                          Get.toNamed(Routes.EDIT_KOS,
                              arguments: controller.kosModel);
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.delete_outline),
                        onPressed: () {
                          Get.defaultDialog(
                              title: 'Hapus post',
                              middleText: 'YAKIN HAPUS POSTINGAN?',
                              onConfirm: () async {
                                controller.dataC
                                    .deleteKos(
                                        userId: controller.kosModel.ownerId,
                                        kostId: controller.kosModel.id)
                                    .whenComplete(
                                      () => Get.offAllNamed(Routes.HOME),
                                    );
                              },
                              onCancel: () {},
                              textConfirm: 'hapus',
                              textCancel: 'batal');
                        },
                      ),
                    ],
                  ),
          ],
        ),
        const SizedBox(
          height: 5,
        ),
        Text(
          GetUtils.capitalize(controller.kosModel.kosName)!,
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        Chip(
          avatar: Icon(Icons.apartment),
          label: Text(
            "Kamar tersedia : ${controller.kosModel.availableRoom}",
          ),
        ),
        Chip(
          avatar: Icon(Icons.bedroom_parent_outlined),
          label: Text(
            " ${controller.kosModel.roomType} Orang / kamar",
          ),
        ),
        SizedBox(
          height: 16,
        ),
        Wrap(
            spacing: 5,
            children: controller.kosModel.facilities
                .map(
                  (fasilitas) => Chip(
                    label: Text(
                      fasilitas,
                      style: TextStyle(color: Colors.white),
                    ),
                    backgroundColor: ReusableWidget.summerPrimary,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                  ),
                )
                .toList()),
        SizedBox(
          height: 16,
        ),
      ],
    );
  }
}
