import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:pesan_kos/app/data/model/dialogModel.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/DetailKos/views/detail_deskripsi.dart';
import 'package:pesan_kos/app/modules/DetailKos/views/detail_image.dart';
import 'package:pesan_kos/app/modules/DetailKos/views/detail_info.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

import '../controllers/detail_kos_controller.dart';

class DetailKosView extends GetView<DetailKosController> {
  const DetailKosView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: ReusableWidget.customAppBar(controller.kosModel.kosName),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              DetailImage(),
              DetailInfo(),
              SizedBox(
                height: 16,
              ),
              Text(
                "Deskripsi",
              ),
              SizedBox(
                height: 16,
              ),
              DetailDeskripsi(),
            ],
          ),
        ),
      ),
      bottomNavigationBar: (controller.kosModel.ownerId ==
              (controller.authC.currentUser.value?.uid ?? ''))
          ? null
          : Padding(
              padding: const EdgeInsets.all(8.0),
              child: ElevatedButton(
                onPressed: () {
                  if (controller.authC.currentUser.value?.uid == null) {
                    DialogModel.ErrorDialog("Anda harus login terlebih dahuku");
                  } else {
                    Get.toNamed(Routes.PESAN_KOS,
                        arguments: [controller.kosModel, controller.userModel]);
                  }
                },
                child: Text("Pesan sekarang"),
              ),
            ),
    );
  }
}
