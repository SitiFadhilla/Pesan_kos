import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/DetailKos/controllers/detail_kos_controller.dart';
import 'package:readmore/readmore.dart';

class DetailDeskripsi extends GetView<DetailKosController> {
  const DetailDeskripsi({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ReadMoreText(
          controller.kosModel.description,
          trimLines: 5,
          trimMode: TrimMode.Line,
          moreStyle: TextStyle(color: ReusableWidget.summerPrimary),
          trimExpandedText: ' tutup deskripsi',
          trimCollapsedText: ' baca lebih lanjut',
          lessStyle: TextStyle(color: ReusableWidget.summerPrimary),
        ),
      ],
    );
  }
}
