import 'package:get/get.dart';
import 'package:pesan_kos/app/controllers/auth_controller.dart';
import 'package:pesan_kos/app/controllers/firestore_controller.dart';
import 'package:pesan_kos/app/controllers/user_model_controller.dart';
import 'package:pesan_kos/app/data/model/chatRoomModel.dart';
import 'package:pesan_kos/app/data/model/kosModel.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

class DetailKosController extends GetxController {
  final dataC = FirestoreController.instance;
  final authC = AuthController.instance;
  final userC = UserModelController.instance;

  var favIsExist = false.obs;

  KosModel kosModel = Get.arguments;
  UserModel get userModel => userC.userModel.value!;
  var imageIndex = 0.obs;

  void createChatRoom(
      {required String userId,
      required String targetId,
      required String roomName,
      required UserModel users}) async {
    var roomReferences =
        await dataC.readRoomInfo(userId: userId, targetId: targetId);

    if (roomReferences.exists) {
      ChatRoom roomModel =
          ChatRoom.fromMap(roomReferences.data() as Map<String, dynamic>);
      Get.toNamed(Routes.CHAT_ROOM, arguments: roomModel);
      print(true);
    } else {
      ChatRoom roomModel = ChatRoom(
          creatorId: userId,
          targetId: targetId,
          roomName: roomName,
          created_at: DateTime.now(),
          id: '$userId+${targetId}_chatroom',
          targetRoomName: kosModel.kosName);
      Get.toNamed(Routes.CHAT_ROOM, arguments: roomModel);
      print(false);
    }
  }

  @override
  void onInit() async {
    favIsExist.value =
        await dataC.readKosFavourite(userId: userModel.id, kosId: kosModel.id);

    super.onInit();
  }
}
