import 'package:chat_bubbles/chat_bubbles.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:grouped_list/grouped_list.dart';
import 'package:pesan_kos/app/data/model/chatModel.dart';
import 'package:pesan_kos/app/data/model/chatRoomModel.dart';
import 'package:pesan_kos/app/data/reusable.dart';

import '../controllers/chat_room_controller.dart';

class ChatRoomView extends GetView<ChatRoomController> {
  ChatRoomView({Key? key}) : super(key: key);
  ChatRoom roomInfo = Get.arguments;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: controller.obx(
          (chats) => Text(
            (roomInfo.creatorId == controller.userModel.id)
                ? roomInfo.targetRoomName
                : roomInfo.roomName,
          ),
        ),
      ),
      body: controller.obx((chats) => buildBodyChat(chats: chats!)),
    );
  }

  Widget buildBodyChat({required List<ChatModel> chats}) {
    return Column(
      children: [
        Expanded(
          child: GroupedListView<ChatModel, DateTime>(
            order: GroupedListOrder.DESC,
            reverse: true,
            elements: chats,
            groupHeaderBuilder: (element) => const SizedBox(
              height: 10,
            ),
            groupBy: (chat) => chat.created_at,
            itemBuilder: (context, chat) {
              return Obx(
                () => BubbleNormal(
                  text: chat.text,
                  textStyle: TextStyle(
                    color: (chat.senderId == controller.userModel.id)
                        ? Colors.white
                        : Colors.white,
                    fontSize: 16,
                  ),
                  color: (chat.senderId == controller.userModel.id)
                      ? ReusableWidget.summerPrimary
                      : ReusableWidget.summerPrice,
                  isSender: (chat.senderId == controller.userModel.id),
                ),
              );
            },
          ),
        ),
        SizedBox(
          height: 20,
        ),
        MessageBar(
          onSend: (text) async {
            if (text.isNotEmpty) {
              var model = ChatModel(
                text: text,
                senderId: controller.userModel.id,
                targetId: roomInfo.targetId,
                created_at: DateTime.now(),
              );
              controller.dataC
                  .addRoomInfo(
                      userId: roomInfo.creatorId,
                      targetId: roomInfo.targetId,
                      room: roomInfo.toMap())
                  .then(
                    (value) => controller.dataC.addChatContent(
                      roomId: roomInfo.id,
                      chats: model.toMap(),
                    ),
                  );
            }
          },
        )
      ],
    );
  }
}
