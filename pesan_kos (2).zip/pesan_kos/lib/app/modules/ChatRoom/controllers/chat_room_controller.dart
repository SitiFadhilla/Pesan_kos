import 'package:get/get.dart';
import 'package:pesan_kos/app/controllers/auth_controller.dart';
import 'package:pesan_kos/app/controllers/firestore_controller.dart';
import 'package:pesan_kos/app/controllers/storage_controller.dart';
import 'package:pesan_kos/app/controllers/user_model_controller.dart';
import 'package:pesan_kos/app/data/fcm_api_provider.dart';
import 'package:pesan_kos/app/data/model/chatModel.dart';
import 'package:pesan_kos/app/data/model/chatRoomModel.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';

class ChatRoomController extends GetxController
    with StateMixin<List<ChatModel>> {
  final authC = AuthController.instance;
  final dataC = FirestoreController.instance;
  final storageC = StorageController.instance;
  final userC = UserModelController.instance;
  final fcmApi = FcmApiProvider();

  RxList<ChatModel> chats = RxList.empty();
  ChatRoom roomInfo = Get.arguments;
  UserModel get userModel => userC.userModel.value!;
  @override
  void onInit() {
    chats.bindStream(
      dataC
          .streamChatContent(
              userId: roomInfo.creatorId, targetId: roomInfo.targetId)
          .asyncMap(
        (event) {
          change(
            event,
            status: RxStatus.success(),
          );
          return event;
        },
      ),
    );

    super.onInit();
  }
}
