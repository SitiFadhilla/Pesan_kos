import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:pesan_kos/app/data/model/paymentModel.dart';
import 'package:pesan_kos/app/modules/Payment/controllers/payment_controller.dart';

class PaymentPay extends GetView<PaymentController> {
  const PaymentPay({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAliasWithSaveLayer,
      child: Column(
        children: [
          ...controller.payMentType.map(
            (payment) => ListTile(
              leading: Obx(
                () => Radio(
                  value: payment['type'],
                  groupValue: controller.isPayNow.value,
                  onChanged: (value) {
                    controller.isPayNow.value = value;
                  },
                ),
              ),
              title: Text(
                payment["label"],
              ),
            ),
          ),
          ListTile(
            tileColor: Colors.blueGrey,
            onTap: () {
              controller.placePayment();
            },
            leading: Icon(
              Icons.arrow_right_alt,
              color: Colors.white,
            ),
            title: Text(
              "Lanjut",
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}
