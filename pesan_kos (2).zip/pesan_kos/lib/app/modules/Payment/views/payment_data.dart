import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:pesan_kos/app/modules/Payment/controllers/payment_controller.dart';

class PaymentData extends GetView<PaymentController> {
  const PaymentData({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Column(
        children: [
          ListTile(
            leading: Icon(Icons.person),
            title: Text(controller.bookedModel.bookerName),
            subtitle: Text(controller.bookedModel.bookerModel.pekerjaan!),
          ),
          ListTile(
            leading: Icon(Icons.calendar_month),
            title: Text(
                "Mulai: ${DateFormat('EEE, d/M/y').format(controller.bookedModel.startDay)}"),
            subtitle: Text(
                "Akhir: ${DateFormat('EEE, d/M/y').format(controller.bookedModel.endDay)}"),
          ),
          ListTile(
            leading: Icon(Icons.calendar_month),
            title: Text("${controller.bookedModel.bookDuration} bulan"),
            subtitle: Text("durasi (bulan)"),
          ),
          ListTile(
            leading: Icon(Icons.money),
            title: Text(
                "${NumberFormat.currency(locale: "id_ID", name: "ID", symbol: "IDR").format(controller.bookedModel.price)}"),
            subtitle: Text("total harga"),
          ),
        ],
      ),
    );
  }
}
