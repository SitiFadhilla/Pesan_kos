import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:pesan_kos/app/modules/Payment/controllers/payment_controller.dart';

class PaymentItem extends GetView<PaymentController> {
  const PaymentItem({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(Icons.apartment),
        title: Text(controller.bookedModel.kosName),
        subtitle: Text(controller.bookedModel.location),
      ),
    );
  }
}
