import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/Payment/views/payment_data.dart';
import 'package:pesan_kos/app/modules/Payment/views/payment_item.dart';
import 'package:pesan_kos/app/modules/Payment/views/payment_pay.dart';

import '../controllers/payment_controller.dart';

class PaymentView extends GetView<PaymentController> {
  const PaymentView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: ReusableWidget.customAppBar("Payment"),
      body: Padding(
        padding: EdgeInsets.all(8),
        child: SingleChildScrollView(
          child: Column(
            children: [
              PaymentItem(),
              PaymentData(),
              PaymentPay(),
            ],
          ),
        ),
      ),
    );
  }
}
