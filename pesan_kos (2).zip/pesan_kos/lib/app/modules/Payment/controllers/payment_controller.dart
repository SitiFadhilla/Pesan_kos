import 'package:get/get.dart';
import 'package:pesan_kos/app/controllers/firestore_controller.dart';
import 'package:pesan_kos/app/controllers/user_model_controller.dart';
import 'package:pesan_kos/app/data/fcm_api_provider.dart';
import 'package:pesan_kos/app/data/model/bookModel.dart';
import 'package:pesan_kos/app/data/model/dialogModel.dart';
import 'package:pesan_kos/app/data/model/kosModel.dart';
import 'package:pesan_kos/app/data/model/paymentModel.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

class PaymentController extends GetxController {
  final dataC = FirestoreController.instance;
  final fcmApi = FcmApiProvider();
  final userC = UserModelController.instance;
  BookModel bookedModel = Get.arguments[0];
  KosModel kostModel = Get.arguments[1];

  UserModel get user => userC.userModel.value!;
  Rxn<UserModel> owner = Rxn();

  List<Map<String, dynamic>> payMentType = [
    {"label": "Bayar Sekarang", "type": true},
    {"label": "Bayar Nanti", "type": false},
  ];

  var isPayNow = true.obs;

  void placePayment() {
    PaymentModel model = PaymentModel(
      id: bookedModel.kosId + user.id,
      isPayNow: isPayNow.value,
      isPayed: isPayNow.value,
      price: bookedModel.price.toDouble(),
      dp: (isPayNow.value) ? bookedModel.price * 0.3 : 0,
      bookerId: user.id,
      ownerId: kostModel.ownerId,
      bookedKos: bookedModel,
      bookerName: bookedModel.bookerName,
      kosId: bookedModel.kosId,
      kostName: bookedModel.kosName,
    );
    if (isPayNow.value) {
      Get.toNamed(Routes.PAY_NOW, arguments: model);
    } else {
      DialogModel.ConfirmationDialog(
        title: "Konfirmasi",
        middleText:
            "Sudah yakin dengan pesanan?, info pesanan akan masuk di daftar booking ( Profile )",
        confirmation: () async {
          await dataC
              .addBooker(
                ownerId: kostModel.ownerId,
                paymentModel: model,
                userId: user.id,
              )
              .whenComplete(
                () => fcmApi
                    .sendOrder(
                        title: bookedModel.bookerName,
                        body: "Memesan Kamar",
                        fcmToken: owner.value!.token)
                    .whenComplete(
                      () => Get.offAllNamed(Routes.HOME),
                    ),
              );
        },
      );
    }
  }

  @override
  void onInit() {
    owner.bindStream(dataC.readUser(id: kostModel.ownerId));
    super.onInit();
  }
}
