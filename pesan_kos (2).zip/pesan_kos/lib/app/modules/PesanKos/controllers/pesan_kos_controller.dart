import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pesan_kos/app/data/model/bookModel.dart';
import 'package:pesan_kos/app/data/model/dialogModel.dart';
import 'package:pesan_kos/app/data/model/kosModel.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

class PesanKosController extends GetxController {
  TextEditingController controllerNama = TextEditingController();
  TextEditingController controllerPekerjaan = TextEditingController();

  Rx<DateTime> tanggalMulai = Rx(DateTime.now());

  KosModel kos = Get.arguments[0];
  UserModel user = Get.arguments[1];
  var duration = 1.obs;
  var jumlah = 1.obs;
  var jenisKelamin = ["MALE", "FEMALE"];
  var selectedGender = "MALE".obs;

  List<Map<String, dynamic>> get textFieldInfo => [
        {
          "label": "Nama penyewa",
          "controller": controllerNama,
          "type": TextInputType.text
        },
        {
          "label": "Pekerjaan",
          "controller": controllerPekerjaan,
          "type": TextInputType.text
        },
      ];

  void addDuration() {
    duration.value += 1;
  }

  void removeDuration() {
    if (duration.value > 1) {
      duration.value -= 1;
    }
  }

  void addToPayment() {
    if (kos.availableRoom > 0) {
      if ((controllerNama.text.isNotEmpty ||
          controllerPekerjaan.text.isNotEmpty)) {
        var id = "${user.email + kos.id}";
        BookModel model = BookModel(
          id: id,
          bookedKos: kos,
          bookerModel: user,
          startDay: tanggalMulai.value,
          endDay: tanggalMulai.value.add(Duration(days: duration.value * 30)),
          bookDuration: duration.value,
          bookerName: controllerNama.text,
          kosName: kos.kosName,
          location: kos.location,
          price: kos.price * duration.value,
          kosId: kos.id,
          bookerId: user.id,
        );
        Get.toNamed(Routes.PAYMENT, arguments: [model, kos]);
      } else {
        DialogModel.ErrorDialog("MOHON PERIKSA DATA");
      }
    } else {
      DialogModel.ErrorDialog("KAMAR TIDAK CUKUP");
    }
  }
}
