import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/PesanKos/views/pesan_kos_item.dart';

import '../controllers/pesan_kos_controller.dart';

class PesanKosView extends GetView<PesanKosController> {
  const PesanKosView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: ReusableWidget.customAppBar("Pesan kos"),
      body: PesanKosItem(),
    );
  }
}
