import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:pesan_kos/app/data/model/bookModel.dart';
import 'package:pesan_kos/app/data/model/dialogModel.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/PesanKos/controllers/pesan_kos_controller.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

class PesanKosItem extends GetView<PesanKosController> {
  const PesanKosItem({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          children: [
            Text(
              controller.kos.kosName,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            SizedBox(
              height: 16,
            ),
            Obx(() => ReusableWidget.customWidget(
                  child: ListTile(
                    title: Text(DateFormat('EEE, d/M/y')
                        .format(controller.tanggalMulai.value)),
                    subtitle: Text("Mulai"),
                    leading: Icon(Icons.calendar_month),
                  ),
                )),
            SizedBox(
              height: 16,
            ),
            ElevatedButton(
              onPressed: () {
                showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime.now(),
                  lastDate: DateTime(3000),
                ).then((value) =>
                    controller.tanggalMulai.value = value ?? DateTime.now());
              },
              child: Text("pilih tanggal"),
            ),
            SizedBox(
              height: 10,
            ),
            ReusableWidget.customWidget(
              child: ListTile(
                leading: IconButton(
                  onPressed: () => controller.removeDuration(),
                  icon: Icon(Icons.remove),
                ),
                title: Obx(
                  () => Text(
                    "Selama ${controller.duration.value} bulan",
                  ),
                ),
                trailing: IconButton(
                  onPressed: () => controller.addDuration(),
                  icon: Icon(Icons.add),
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            SizedBox(
              height: 10,
            ),
            ElevatedButton(
              onPressed: () {
                controller.controllerNama.text = controller.user.name!;
                controller.selectedGender.value = controller.user.jenisKelamin;

                controller.controllerPekerjaan.text =
                    controller.user.pekerjaan!;
              },
              child: Text("Gunakan data saya"),
            ),
            SizedBox(
              height: 10,
            ),
            ...controller.textFieldInfo
                .map(
                  (e) => Container(
                    margin: EdgeInsets.only(top: 5, bottom: 5),
                    child: ReusableWidget.customWidget(
                      child: TextField(
                        controller: e["controller"],
                        decoration: InputDecoration(
                            labelText: e["label"], border: InputBorder.none),
                        keyboardType: e["type"],
                      ),
                    ),
                  ),
                )
                .toList(),
            ...controller.jenisKelamin.map(
              (e) => Obx(
                () => Container(
                  margin: EdgeInsets.only(top: 5, bottom: 5),
                  child: ReusableWidget.customWidget(
                    child: ListTile(
                      leading: Radio<String>(
                        value: e,
                        groupValue: controller.selectedGender.value,
                        onChanged: (value) =>
                            controller.selectedGender.value = value!,
                      ),
                      title: Text(e),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            ElevatedButton(
              onPressed: () {
                controller.addToPayment();
              },
              child: Text("Sewa sekarang"),
            )
          ],
        ),
      ),
    );
  }
}
