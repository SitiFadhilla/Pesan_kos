import 'package:get/get.dart';

import '../controllers/pesan_kos_controller.dart';

class PesanKosBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<PesanKosController>(
      () => PesanKosController(),
    );
  }
}
