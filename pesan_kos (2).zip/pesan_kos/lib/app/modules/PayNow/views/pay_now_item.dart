import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:pesan_kos/app/data/model/dialogModel.dart';
import 'package:pesan_kos/app/modules/PayNow/controllers/pay_now_controller.dart';

class PayNowItem extends GetView<PayNowController> {
  const PayNowItem({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAliasWithSaveLayer,
      child: Column(
        children: [
          ListTile(
            leading: Icon(Icons.credit_card),
            title: Text("123456789012"),
            subtitle: Text("Nomor rekening"),
          ),
          ...controller.pelunasan.map(
            (payment) => ListTile(
              leading: Obx(
                () => Radio(
                  value: payment['type'],
                  groupValue: controller.lunasType.value,
                  onChanged: (value) {
                    controller.lunasType.value = value;
                  },
                ),
              ),
              title: Text(
                payment["label"],
              ),
            ),
          ),
          ListTile(
            leading: Icon(Icons.money),
            title: Text(
                "${NumberFormat.currency(locale: "id_ID", name: "ID", symbol: "IDR").format(controller.paymentModel.price)}"),
            subtitle: Text("total harga"),
          ),
          ListTile(
            leading: Icon(Icons.money),
            title: Text(
                "${NumberFormat.currency(locale: "id_ID", name: "ID", symbol: "IDR").format(controller.paymentModel.dp)}"),
            subtitle: Text("DP"),
          ),
          ListTile(
            leading: Icon(Icons.money),
            title: Text(
                "${NumberFormat.currency(locale: "id_ID", name: "ID", symbol: "IDR").format(controller.paymentModel.price - controller.paymentModel.dp)}"),
            subtitle: Text("sisa pembayaran (jika DP)"),
          ),
          ListTile(
            tileColor: Colors.blueGrey.shade300,
            onTap: () async {
              controller.selectedFile.value = await controller.pickImage();
            },
            leading: Icon(
              Icons.upload_file,
              color: Colors.white,
            ),
            title: Text(
              "Upload Bukti",
              style: TextStyle(color: Colors.white),
            ),
            subtitle: Obx(
              () => Text(
                controller.namaFile.value,
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
          ListTile(
            tileColor: Colors.blueGrey,
            onTap: () {
              if (controller.selectedFile.value != null) {
                controller.proceedBooking(
                    file: controller.selectedFile.value!,
                    payModel: controller.paymentModel);
              } else {
                DialogModel.ErrorDialog("UPLOAD BUKTI TERLEBIH DAHULU");
              }
            },
            leading: Icon(
              Icons.arrow_right_alt,
              color: Colors.white,
            ),
            title: Text(
              "Lanjut",
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}
