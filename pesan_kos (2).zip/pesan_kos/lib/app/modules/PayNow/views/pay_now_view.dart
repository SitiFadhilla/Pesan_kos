import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/PayNow/views/pay_now_item.dart';

import '../controllers/pay_now_controller.dart';

class PayNowView extends GetView<PayNowController> {
  const PayNowView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: ReusableWidget.customAppBar("Pay Now"),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            PayNowItem(),
          ],
        ),
      ),
    );
  }
}
