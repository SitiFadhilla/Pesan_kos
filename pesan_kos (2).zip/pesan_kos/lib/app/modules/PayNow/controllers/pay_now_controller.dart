import 'dart:io';

import 'package:flutter_native_image/flutter_native_image.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:pesan_kos/app/controllers/firestore_controller.dart';
import 'package:pesan_kos/app/controllers/storage_controller.dart';
import 'package:pesan_kos/app/controllers/user_model_controller.dart';
import 'package:pesan_kos/app/data/fcm_api_provider.dart';
import 'package:pesan_kos/app/data/model/dialogModel.dart';
import 'package:pesan_kos/app/data/model/paymentModel.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

class PayNowController extends GetxController {
  final dataC = FirestoreController.instance;
  final storageC = StorageController.instance;
  final userC = UserModelController.instance;
  final fcmAPI = FcmApiProvider();

  UserModel get userModel => userC.userModel.value!;
  PaymentModel paymentModel = Get.arguments;
  Rxn<UserModel> owner = Rxn();

  List<Map<String, dynamic>> pelunasan = [
    {"label": "Lunas", "type": true},
    {"label": "Dp", "type": false},
  ];

  var namaFile = "nama file".obs;
  var lunasType = true.obs;
  Rxn<XFile> selectedFile = Rxn();

  Future<XFile?> pickImage() async {
    return await ImagePicker().pickImage(source: ImageSource.gallery).then(
      (value) async {
        if (value != null) {
          namaFile.value = value.name;
        }
        return value;
      },
    );
  }

  Future proceedBooking(
      {required XFile file, required PaymentModel payModel}) async {
    DialogModel.ConfirmationDialog(
      title: "Konfirmasi",
      middleText:
          "Sudah yakin dengan pesanan?, info pesanan akan masuk di daftar booking ( Profile )",
      confirmation: () async {
        await storageC
            .uploadBuktiTransfer(
          id: userModel.id,
          name: userModel.name!,
          file: File(file.path),
        )
            .then(
          (value) async {
            PaymentModel model = (lunasType.value)
                ? payModel.copyWith(buktiTransfer: value, dp: 0)
                : payModel.copyWith(
                    buktiTransfer: value,
                    price: payModel.price - payModel.dp,
                    isPayed: false);
            await dataC
                .addBooker(
                  ownerId: payModel.bookedKos.bookedKos.ownerId,
                  paymentModel: model,
                  userId: userModel.id,
                )
                .whenComplete(
                  () => fcmAPI
                      .sendOrder(
                          title: userModel.name!,
                          body: "Memesan Kamar dengan transfer",
                          fcmToken: owner.value!.token)
                      .whenComplete(
                        () => Get.offAllNamed(Routes.HOME),
                      ),
                );
          },
        );
      },
    );
  }

  @override
  void onInit() {
    owner.bindStream(dataC.readUser(id: paymentModel.ownerId));
    super.onInit();
  }
}
