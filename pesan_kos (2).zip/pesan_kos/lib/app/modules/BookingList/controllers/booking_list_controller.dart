import 'package:get/get.dart';
import 'package:pesan_kos/app/controllers/auth_controller.dart';
import 'package:pesan_kos/app/controllers/firestore_controller.dart';
import 'package:pesan_kos/app/controllers/user_model_controller.dart';
import 'package:pesan_kos/app/data/fcm_api_provider.dart';
import 'package:pesan_kos/app/data/model/paymentModel.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';

class BookingListController extends GetxController
    with StateMixin<List<PaymentModel>> {
  final authC = AuthController.instance;
  final dataC = FirestoreController.instance;
  final userC = UserModelController.instance;
  final fcmApi = FcmApiProvider();

  UserModel get user => userC.userModel.value!;
  Rxn<UserModel> booker = Rxn();
  RxList<PaymentModel> daftarBooking = RxList.empty();

  @override
  void onInit() {
    daftarBooking.bindStream(
      dataC.readAllBooking(id: user.id).asyncMap(
        (payments) {
          if (payments.isNotEmpty) {
            change(payments, status: RxStatus.success());
          } else {
            change(payments, status: RxStatus.empty());
          }
          return payments;
        },
      ),
    );
    super.onInit();
  }
}
