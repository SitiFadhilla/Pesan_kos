import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/BookingList/views/booking_item.dart';

import '../controllers/booking_list_controller.dart';

class BookingListView extends GetView<BookingListController> {
  const BookingListView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: ReusableWidget.customAppBar("Daftar Booking"),
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(8.0),
          child: BookingItem(),
        ),
      ),
    );
  }
}
