import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:pesan_kos/app/data/model/dialogModel.dart';
import 'package:pesan_kos/app/data/model/kosModel.dart';
import 'package:pesan_kos/app/data/model/paymentModel.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/BookingList/controllers/booking_list_controller.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';
import 'package:url_launcher/url_launcher.dart';

class BookingItem extends GetView<BookingListController> {
  const BookingItem({super.key});

  @override
  Widget build(BuildContext context) {
    return controller.obx(
      (daftarBooking) => ListView.separated(
        itemCount: daftarBooking!.length,
        separatorBuilder: (context, index) => SizedBox(
          height: 16,
        ),
        itemBuilder: (context, index) {
          PaymentModel model = daftarBooking[index];
          return Obx(
            () => buildCardItem(
                model: model, kostModel: model.bookedKos.bookedKos),
          );
        },
      ),
    );
  }

  Widget buildCardItem(
      {required PaymentModel model, required KosModel? kostModel}) {
    return Card(
      clipBehavior: Clip.antiAliasWithSaveLayer,
      child: Column(
        children: [
          ListTile(
            title: Text(model.bookerName),
            subtitle: Text("nama pemesan"),
            leading: Icon(Icons.person),
          ),
          ListTile(
            title: Text(model.kostName),
            subtitle: Text("nama kos"),
            leading: Icon(Icons.apartment),
          ),
          ListTile(
            title: Text((model.isPayed) ? "Lunas" : "Belum Lunas"),
            subtitle: Text("status pembayaran"),
            leading: Icon(Icons.done),
          ),
          ListTile(
            title: Text((model.isPayNow) ? "Transfer" : "Ditempat"),
            subtitle: Text("metode bayar"),
            leading: Icon(Icons.credit_card),
          ),
          ListTile(
            title: Text(
                "${NumberFormat.currency(locale: "id_ID", name: "ID", symbol: "IDR").format(model.price)}"),
            subtitle: Text("total pembayaran"),
            leading: Icon(Icons.money),
          ),
          ListTile(
            title: Text(
                "${NumberFormat.currency(locale: "id_ID", name: "ID", symbol: "IDR").format(model.dp)}"),
            subtitle: Text("dp"),
            leading: Icon(Icons.money),
          ),
          ListTile(
            title: Text(
                "${NumberFormat.currency(locale: "id_ID", name: "ID", symbol: "IDR").format(model.price - model.dp)}"),
            subtitle: Text("sisa pembayaran"),
            leading: Icon(Icons.money),
          ),
          if (controller.user.status == "OWNER")
            ListTile(
              onTap: () async {
                if (model.buktiTransfer != null) {
                  await launchUrl(Uri.parse(model.buktiTransfer!),
                      mode: LaunchMode.externalApplication);
                }
              },
              title: Text((model.buktiTransfer == null)
                  ? "tidak ada bukti transfer"
                  : "lihat bukti transfer"),
              subtitle: Text("sisa pembayaran"),
              leading: Icon(Icons.money),
            ),
          if (controller.user.status == "OWNER")
            ListTile(
              tileColor: ReusableWidget.summerPrimary,
              onTap: () {
                DialogModel.ConfirmationDialog(
                  title: "Lunaskan?",
                  middleText:
                      "pesanan atas nama '${model.bookerName}' untuk kos '${model.kostName}' akan dilunaskan",
                  confirmation: () {
                    controller.dataC
                        .addRenter(
                            ownerId: controller.user.id,
                            paymentModel: model,
                            bookedModel: model.bookedKos,
                            userId: model.bookedKos.bookerId,
                            value: kostModel!.availableRoom -
                                model.bookedKos.quantity)
                        .then(
                      (value) {
                        print(kostModel.availableRoom);
                        Rxn<UserModel> booker = Rxn();
                        booker.bindStream(
                          controller.dataC
                              .readUser(id: model.bookerId)
                              .asyncMap(
                            (event) {
                              controller.fcmApi.sendOrder(
                                  title: "Lunas",
                                  body: "${model.kostName} dilunaskan",
                                  fcmToken: event.token);
                              return value;
                            },
                          ),
                        );
                      },
                    ).whenComplete(
                      () {
                        controller.dataC.deleteBooking(
                            ownerId: controller.user.id,
                            paymentModel: model,
                            userId: model.bookedKos.bookerId);
                        Get.back();
                      },
                    );
                  },
                );
              },
              title: Text(
                "Tandai Lunas",
                style: TextStyle(
                  color: Colors.white,
                ),
              ),
              leading: Icon(
                Icons.approval,
                color: Colors.white,
              ),
            ),
          ListTile(
            onTap: () {
              DialogModel.ConfirmationDialog(
                title: "Pembatalan",
                middleText:
                    "pesanan atas nama '${model.bookerName}' untuk kos '${model.kostName}' akan dilunaskan",
                confirmation: () {
                  controller.dataC
                      .deleteBooking(
                          ownerId: controller.user.id,
                          paymentModel: model,
                          userId: model.bookedKos.bookerId)
                      .then(
                    (value) {
                      Rxn<UserModel> booker = Rxn();
                      booker.bindStream(
                        controller.dataC.readUser(id: model.bookerId).asyncMap(
                          (event) {
                            controller.fcmApi.sendOrder(
                                title: "Batal",
                                body: "${model.kostName} dibatalkan",
                                fcmToken: (controller.user.id == event.id)
                                    ? model.ownerId
                                    : event.token);
                            Get.back();
                            return value;
                          },
                        ),
                      );
                    },
                  );
                },
              );
            },
            leading: Icon(
              Icons.remove,
              color: Colors.white,
            ),
            title: Text(
              "Batalkan",
              style: TextStyle(
                color: Colors.white,
              ),
            ),
            tileColor: Colors.blueGrey.shade400,
          )
        ],
      ),
    );
  }
}
