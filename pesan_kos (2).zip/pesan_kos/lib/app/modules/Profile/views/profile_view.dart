import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/Profile/views/profil_user.dart';
import 'package:pesan_kos/app/modules/Profile/views/profile_owner.dart';

import '../controllers/profile_controller.dart';

class ProfileView extends GetView<ProfileController> {
  const ProfileView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: ReusableWidget.customAppBar("Profile"),
      body: Center(
        child: controller.obx((user) =>
            (user!.status != "USER") ? ProfileOwner() : ProfileUser()),
      ),
    );
  }
}
