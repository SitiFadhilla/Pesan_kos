import 'package:get/get.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/Profile/controllers/profile_controller.dart';
import 'package:flutter/material.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

class ProfileOwner extends GetView<ProfileController> {
  const ProfileOwner({super.key});

  @override
  Widget build(BuildContext context) {
    return controller.obx(
      (user) => SingleChildScrollView(
        child: Column(
          children: [
            ReusableWidget.customWidget(
              isAvatar: true,
              child: CircleAvatar(
                radius: 80,
                backgroundColor: ReusableWidget.summerPrimary,
                child: (user!.image != null)
                    ? null
                    : Icon(
                        Icons.person,
                        size: 120,
                        color: Colors.white,
                      ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.person),
              title: Text(user.name!),
              subtitle: Text("nama"),
            ),
            ListTile(
              leading: Icon(Icons.email),
              title: Text(user.email),
              subtitle: Text("email"),
            ),
            ListTile(
              leading: Icon(
                (user.jenisKelamin == "Pria") ? Icons.person : Icons.person_2,
              ),
              title: Text(user.jenisKelamin),
              subtitle: Text("jenis kelamin"),
            ),
            ListTile(
              leading: Icon(Icons.supervised_user_circle),
              title: Text(user.status),
              subtitle: Text("jenis akun"),
            ),
            ListTile(
              leading: Icon(Icons.apartment),
              onTap: () {
                Get.toNamed(Routes.RENTED_KOS);
              },
              title: Text("Kos yang disewakan"),
            ),
            ListTile(
              leading: Icon(Icons.receipt),
              onTap: () {
                Get.toNamed(Routes.BOOKING_LIST);
              },
              title: Text("Daftar booking"),
            ),
            ListTile(
              onTap: () {
                controller.logOut();
              },
              leading: Icon(Icons.logout),
              title: Text("Logout"),
            ),
          ],
        ),
      ),
    );
  }
}
