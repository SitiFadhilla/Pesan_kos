import 'package:get/get.dart';
import 'package:pesan_kos/app/controllers/auth_controller.dart';
import 'package:pesan_kos/app/controllers/firestore_controller.dart';
import 'package:pesan_kos/app/controllers/user_model_controller.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

class ProfileController extends GetxController with StateMixin<UserModel> {
  final authC = AuthController.instance;
  final dataC = FirestoreController.instance;
  final userC = UserModelController.instance;

  UserModel get userModel => userC.userModel.value!;

  Future logOut() async {
    await dataC.updateToken(id: userModel.id, token: "");
    await authC.logOut().whenComplete(
          () => Get.offAllNamed(Routes.LOGIN),
        );
  }

  @override
  void onInit() {
    change(userModel, status: RxStatus.success());
    super.onInit();
  }
}
