import 'package:get/get.dart';
import 'package:pesan_kos/app/controllers/firestore_controller.dart';
import 'package:pesan_kos/app/controllers/user_model_controller.dart';
import 'package:pesan_kos/app/data/model/kosModel.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';

class FavouriteController extends GetxController
    with StateMixin<List<KosModel>> {
  final dataC = FirestoreController.instance;
  final userC = UserModelController.instance;

  var daftarBuku = RxList<KosModel>.empty();
  UserModel get user => userC.userModel.value!;

  @override
  void onInit() {
    daftarBuku
        .bindStream(dataC.streamFavourite(userId: user.id).asyncMap((event) {
      change(event, status: RxStatus.success());
      return event;
    }));
    super.onInit();
  }
}
