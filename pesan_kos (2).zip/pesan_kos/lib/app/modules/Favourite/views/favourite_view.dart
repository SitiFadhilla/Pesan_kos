import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:pesan_kos/app/data/model/kosModel.dart';
import 'package:pesan_kos/app/modules/Favourite/controllers/favourite_controller.dart';

import 'package:intl/intl.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

class FavouriteView extends GetView<FavouriteController> {
  const FavouriteView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Tersimpan'),
        ),
        body: controller
            .obx((daftarKos) => buildBodyFavourite(daftarKos: daftarKos!)));
  }

  Widget buildBodyFavourite({required List<KosModel> daftarKos}) {
    return ListView.separated(
      separatorBuilder: (context, index) => Divider(),
      itemCount: daftarKos.length,
      itemBuilder: (context, index) {
        KosModel kosModel = daftarKos[index];

        return ListTile(
          onTap: () => Get.toNamed(Routes.DETAIL_KOS, arguments: kosModel),
          title: Text(GetUtils.capitalize(kosModel.kosName)!),
          leading: CachedNetworkImage(
            imageUrl: kosModel.image[0],
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(kosModel.location),
              Text(
                NumberFormat.simpleCurrency(locale: 'id')
                    .format(kosModel.price),
              ),
            ],
          ),
        );
      },
    );
  }
}
