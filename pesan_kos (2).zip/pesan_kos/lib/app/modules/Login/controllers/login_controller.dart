import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:pesan_kos/app/controllers/auth_controller.dart';
import 'package:pesan_kos/app/controllers/firestore_controller.dart';
import 'package:pesan_kos/app/data/model/dialogModel.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

class LoginController extends GetxController {
  // Memanggil depedency
  final authC = AuthController.instance;
  final dataC = FirestoreController.instance;

  // Text Controllers
  final emailTextController = TextEditingController();
  final passwordTextController = TextEditingController();

  RxnString deviceToken = RxnString();

  // Validating input
  String? validateEmail({required String value}) {
    if (!GetUtils.isEmail(value) || value.isEmpty) {
      return "email tidak valid";
    } else {
      return null;
    }
  }

  String? validatePassword({required String value}) {
    if (value.length < 8 || value.isEmpty) {
      return "password belum valid";
    } else {
      return null;
    }
  }

  // Login function
  void loginUser() async {
    if (await Permission.notification.isGranted) {
      authC
          .logInUser(
              email: emailTextController.text,
              password: passwordTextController.text)
          .then(
        (value) {
          if (value != null) {
            dataC
                .updateToken(id: value.user!.uid, token: deviceToken.value!)
                .whenComplete(() => Get.offAllNamed(Routes.HOME));
          }
        },
      );
    }

    if (await Permission.notification.isDenied ||
        await Permission.notification.isDenied) {
      openAppSettings();
    }
  }

  @override
  void onInit() async {
    deviceToken.value = await FirebaseMessaging.instance.getToken();
    super.onInit();
  }
}
