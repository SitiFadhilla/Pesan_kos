import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pesan_kos/app/data/model/dialogModel.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/Login/controllers/login_controller.dart';
import 'package:pesan_kos/app/routes/app_pages.dart';

class LoginItem extends GetView<LoginController> {
  const LoginItem({super.key});

  @override
  Widget build(BuildContext context) {
    final loginForm = GlobalKey<FormState>();
    return Form(
      key: loginForm,
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ReusableWidget.customWidget(
              child:
                  ReusableWidget.customTitleWidget(data: "Login\nMobile Kos"),
            ),
            SizedBox(
              height: 16,
            ),

            // Email Field
            ReusableWidget.customWidget(
              child: ReusableWidget.customTextFormField(
                label: "Email",
                hint: "Masukkan email",
                inputType: TextInputType.emailAddress,
                isObscured: false.obs,
                textEditingController: controller.emailTextController,
                validator: (value) => controller.validateEmail(value: value!),
              ),
            ),
            SizedBox(
              height: 16,
            ),

            // Password Field
            ReusableWidget.customWidget(
              child: ReusableWidget.customTextFormField(
                label: "Password",
                hint: "Masukkan password",
                inputType: TextInputType.visiblePassword,
                isObscured: true.obs,
                textEditingController: controller.passwordTextController,
                enableIcon: true,
                validator: (value) =>
                    controller.validatePassword(value: value!),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Row(
              children: [
                // Route to sign p page
                TextButton(
                  onPressed: () => Get.toNamed(Routes.SIGN_UP),
                  child: Text("belum punya akun? SIGN UP"),
                ),
                Spacer(),
                // Login button
                ElevatedButton(
                  onPressed: () {
                    if (loginForm.currentState!.validate()) {
                      controller.loginUser();
                    }
                  },
                  child: Text("login"),
                ),
              ],
            ),
            // Forget Password button
            TextButton(
              onPressed: () {
                final emailController = TextEditingController();
                Get.defaultDialog(
                  title: "Lupa Password",
                  content: ReusableWidget.customWidget(
                    child: TextField(
                      controller: emailController,
                      decoration: InputDecoration(border: InputBorder.none),
                    ),
                  ),
                  textConfirm: "reset",
                  onConfirm: () async {
                    controller.authC
                        .forgotPassword(email: emailController.text);
                    Get.back();
                  },
                );
              },
              child: Text("lupa password? tekan disini"),
            ),
          ],
        ),
      ),
    );
  }
}
