import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:pesan_kos/app/modules/Login/views/login_item.dart';

import '../controllers/login_controller.dart';

class LoginView extends GetView<LoginController> {
  const LoginView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: LoginItem(),
          ),
        ),
      ),
    );
  }
}
