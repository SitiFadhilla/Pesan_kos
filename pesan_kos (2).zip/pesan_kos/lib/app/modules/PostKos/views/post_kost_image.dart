import 'dart:io';

import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pesan_kos/app/modules/PostKos/controllers/post_kos_controller.dart';

class PosImage extends GetView<PostKosController> {
  const PosImage({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => (controller.pickedImages.isEmpty)
          ? const Text('Silahkan pilih gambar')
          : CarouselSlider(
              items: controller.pickedImages.map((url) {
                File file = File(url);
                return Stack(
                  alignment: Alignment.center,
                  children: [
                    Image(
                      fit: BoxFit.cover,
                      image: FileImage(file),
                    ),
                    Align(
                      alignment: Alignment.topRight,
                      child: IconButton(
                        icon: Container(
                          padding: const EdgeInsets.all(5),
                          decoration: const BoxDecoration(
                            color: Colors.grey,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.delete,
                            color: Colors.amber,
                          ),
                        ),
                        onPressed: () {
                          controller.pickedImages.removeWhere(
                            (element) => element == url,
                          );
                        },
                      ),
                    )
                  ],
                );
              }).toList(),
              options: CarouselOptions(
                aspectRatio: 16 / 9,
                viewportFraction: 0.8,
                initialPage: 0,
                reverse: false,
                enableInfiniteScroll: false,
                enlargeCenterPage: true,
                scrollDirection: Axis.horizontal,
              ),
            ),
    );
  }
}
