import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pesan_kos/app/data/model/dialogModel.dart';
import 'package:pesan_kos/app/data/model/kosModel.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/PostKos/controllers/post_kos_controller.dart';
import 'package:pesan_kos/app/modules/PostKos/views/post_kost_image.dart';

class PostKostForm extends GetView<PostKosController> {
  const PostKostForm({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        PosImage(),
        SizedBox(
          height: 10,
        ),
        ReusableWidget.retroButton(
          onTap: () {
            controller.pickImage();
          },
          child: "pilih foto",
        ),
        SizedBox(
          height: 10,
        ),
        ...controller.postTextfieldMap.map(
          (e) => Column(
            children: [
              ReusableWidget.customWidget(
                child: ReusableWidget.customTextFormField(
                  textEditingController: e['controller'],
                  label: e["label"],
                  hint: e["hint"],
                  inputType: e["type"],
                  isObscured: e["obscured"],
                  minLine: e['min'],
                  maxLine: e["max"],
                ),
              ),
              SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
        ReusableWidget.customWidget(
            child: ListTile(
          leading: IconButton(
              onPressed: () {
                controller.removePenyewaMax();
              },
              icon: Icon(Icons.remove)),
          title: Obx(() => Text(controller.penyewaMax.value.toString())),
          subtitle: Text("penyewa maksimal/kamar"),
          trailing: IconButton(
              onPressed: () {
                controller.addPenyewaMax();
              },
              icon: Icon(Icons.add)),
        )),
        SizedBox(
          height: 10,
        ),
        ReusableWidget.customWidget(
            child: ListTile(
          leading: IconButton(
              onPressed: () {
                controller.removeKamarTersedia();
              },
              icon: Icon(Icons.remove)),
          title: Obx(
            () => Text(
              controller.kamarTersedia.value.toString(),
            ),
          ),
          subtitle: Text("jumlah kamar tersedia"),
          trailing: IconButton(
              onPressed: () {
                controller.addKamarTersedia();
              },
              icon: Icon(Icons.add)),
        )),
        SizedBox(
          height: 16,
        ),
        ReusableWidget.retroButton(
          onTap: () {
            if (controller.pickedImages.length == 0 ||
                controller.nametextController.text.isEmpty ||
                controller.pricetextController.text.isEmpty ||
                controller.locationtextController.text.isEmpty ||
                controller.descriptiontextController.text.isEmpty ||
                controller.facilitestextController.text.isEmpty) {
              DialogModel.ErrorDialog("Periksa masukkan");
            } else {
              var kostId =
                  "${controller.nametextController.text}kostof${controller.authC.currentUser.value!.uid}";

              controller.storageC
                  .uploadKosImage(
                      model: controller.user,
                      kosName: controller.nametextController.text,
                      imageList: controller.pickedImages)
                  .then(
                (value) {
                  KosModel model = KosModel(
                      id: kostId,
                      kosName: controller.nametextController.text,
                      price: int.parse(controller.pricetextController.text),
                      location: controller.locationtextController.text,
                      description: controller.descriptiontextController.text,
                      facilities:
                          controller.facilitestextController.text.split(','),
                      roomType: controller.penyewaMax.value,
                      ownerId: controller.authC.currentUser.value!.uid,
                      image: value,
                      availableRoom: controller.kamarTersedia.value,
                      rating: null);
                  controller.dataC
                      .createKos(
                          model: model, userId: model.ownerId, kostId: kostId)
                      .whenComplete(
                        () => DialogModel.ConfirmationDialog(
                          title: "Upload Selesai",
                          middleText:
                              "Kos mu sudah berhasil di upload, silahkan kembali",
                          confirmation: () {
                            Get.back();
                            Get.back();
                          },
                        ),
                      );
                },
              );
            }
          },
          child: "Publish Kos",
        ),
      ],
    );
  }
}
