import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/PostKos/views/post_kost_form.dart';

import '../controllers/post_kos_controller.dart';

class PostKosView extends GetView<PostKosController> {
  const PostKosView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: ReusableWidget.customAppBar("Publish Kos"),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                PostKostForm(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
