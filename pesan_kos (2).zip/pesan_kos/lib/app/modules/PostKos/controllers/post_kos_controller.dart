import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pesan_kos/app/controllers/auth_controller.dart';
import 'package:pesan_kos/app/controllers/firestore_controller.dart';
import 'package:pesan_kos/app/controllers/storage_controller.dart';
import 'package:pesan_kos/app/controllers/user_model_controller.dart';
import 'package:pesan_kos/app/data/model/kosModel.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_native_image/flutter_native_image.dart';

class PostKosController extends GetxController {
  final authC = AuthController.instance;
  final dataC = FirestoreController.instance;
  final storageC = StorageController.instance;
  final userC = UserModelController.instance;

  final nametextController = TextEditingController();
  final pricetextController = TextEditingController();
  final locationtextController = TextEditingController();
  final descriptiontextController = TextEditingController();
  final facilitestextController = TextEditingController();

  KosModel? editKosModel = Get.arguments;

  UserModel get user => userC.userModel.value!;
  RxList<String> pickedImages = RxList.empty();
  var penyewaMax = 1.obs;
  var kamarTersedia = 1.obs;

  void removePenyewaMax() {
    if (penyewaMax != 0) {
      penyewaMax.value--;
    }
  }

  void addPenyewaMax() {
    penyewaMax.value++;
  }

  void removeKamarTersedia() {
    if (kamarTersedia != 0) {
      kamarTersedia.value--;
    }
  }

  void addKamarTersedia() {
    kamarTersedia.value++;
  }

  void pickImage() async {
    await ImagePicker().pickMultiImage().then(
      (value) async {
        for (var element in value) {
          File file = await FlutterNativeImage.compressImage(element.path,
              quality: 80, targetWidth: 1920, targetHeight: 1080);
          pickedImages.add(file.path);
        }
      },
    );
  }

  List<Map<String, dynamic>> get postTextfieldMap => [
        {
          "label": "Nama Kos",
          'controller': nametextController,
          "hint": "masukkan nama kos",
          "type": TextInputType.text,
          "obscured": false.obs,
          "min": 1,
          "max": 1,
          "validator": namaValidator(nametextController.text),
        },
        {
          "label": "Harga Kos",
          'controller': pricetextController,
          "hint": "masukkan harga kos",
          "type": TextInputType.number,
          "obscured": false.obs,
          "min": 1,
          "max": 1,
          "validator": hargaValidator(pricetextController.text)
        },
        {
          "label": "Lokasi Kos",
          'controller': locationtextController,
          "hint": "masukkan lokasi kos",
          "type": TextInputType.text,
          "obscured": false.obs,
          "min": 1,
          "max": 1,
          "validator": lokasiValidator(locationtextController.text)
        },
        {
          "label": "Deskripsi Kos",
          'controller': descriptiontextController,
          "hint": "masukkan deskripsi kos",
          "type": TextInputType.text,
          "obscured": false.obs,
          "min": 3,
          "max": 3,
          "validator": deskripsiValidator(descriptiontextController.text)
        },
        {
          "label": "Fasilitas Kos",
          'controller': facilitestextController,
          "hint": "masukkan fasilitas kos, pisahkan dengan tanda (,)",
          "type": TextInputType.text,
          "obscured": false.obs,
          "min": 2,
          "max": 2,
          "validator": fasilitasValidator(facilitestextController.text)
        },
      ];

  String? namaValidator(String value) {
    if (value.isEmpty) {
      return "harus terisi";
    }
    return null;
  }

  String? hargaValidator(String value) {
    if (value.isEmpty) {
      return "harus terisi";
    }
    return null;
  }

  String? lokasiValidator(String value) {
    if (value.isEmpty) {
      return "harus terisi";
    }
    return null;
  }

  String? deskripsiValidator(String value) {
    if (value.isEmpty) {
      return "harus terisi";
    }
    return null;
  }

  String? fasilitasValidator(String value) {
    if (value.isEmpty) {
      return "harus terisi";
    }
    return null;
  }
}
