import 'package:get/get.dart';

import '../controllers/post_kos_controller.dart';

class PostKosBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<PostKosController>(
      () => PostKosController(),
    );
  }
}
