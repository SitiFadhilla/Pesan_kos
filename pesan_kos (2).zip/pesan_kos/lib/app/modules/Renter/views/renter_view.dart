import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:pesan_kos/app/modules/Renter/views/renter_item.dart';

import '../controllers/renter_controller.dart';

class RenterView extends GetView<RenterController> {
  const RenterView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('RenterView'),
        centerTitle: true,
      ),
      body: const Center(
        child: Padding(
          padding: EdgeInsets.all(8),
          child: RenterItem(),
        ),
      ),
    );
  }
}
