import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:pesan_kos/app/data/model/paymentModel.dart';
import 'package:pesan_kos/app/data/reusable.dart';
import 'package:pesan_kos/app/modules/Renter/controllers/renter_controller.dart';

class RenterItem extends GetView<RenterController> {
  const RenterItem({super.key});

  @override
  Widget build(BuildContext context) {
    return controller.obx(
      (daftarRenter) => ListView.separated(
        itemCount: daftarRenter!.length,
        separatorBuilder: (context, index) => SizedBox(
          height: 16,
        ),
        itemBuilder: (context, index) {
          PaymentModel model = daftarRenter[index];
          return buildCardItem(model: model);
        },
      ),
    );
  }

  Widget buildCardItem({required PaymentModel model}) {
    return Card(
      clipBehavior: Clip.antiAliasWithSaveLayer,
      child: Column(
        children: [
          ListTile(
            title: Text(model.bookerName),
            subtitle: Text("nama pemesan"),
            leading: Icon(Icons.person),
          ),
          ListTile(
            title: Text(model.kostName),
            subtitle: Text("nama kos"),
            leading: Icon(Icons.apartment),
          ),
          ListTile(
            title: Text(
                "${NumberFormat.currency(locale: "id_ID", name: "ID", symbol: "IDR").format(model.price)}"),
            subtitle: Text("total pembayaran"),
            leading: Icon(Icons.money),
          ),
          ListTile(
            onTap: () async {
              controller.dataC.createInvoicePDF(model);
            },
            tileColor: ReusableWidget.summerPrimary,
            title: Text(
              "Cetak incvoice",
              style: TextStyle(color: Colors.white),
            ),
            subtitle: Text(
              "total pembayaran",
              style: TextStyle(color: Colors.white),
            ),
            leading: Icon(Icons.receipt, color: Colors.white),
          ),
        ],
      ),
    );
  }
}
