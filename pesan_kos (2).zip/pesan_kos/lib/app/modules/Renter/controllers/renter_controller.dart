import 'package:get/get.dart';
import 'package:pesan_kos/app/controllers/firestore_controller.dart';
import 'package:pesan_kos/app/controllers/user_model_controller.dart';
import 'package:pesan_kos/app/data/model/paymentModel.dart';

import 'package:pesan_kos/app/data/model/userModel.dart';

class RenterController extends GetxController
    with StateMixin<List<PaymentModel>> {
  final userC = UserModelController.instance;
  final dataC = FirestoreController.instance;

  UserModel get user => userC.userModel.value!;

// crete invoice

  RxList<PaymentModel> daftarRenter = RxList();
  @override
  void onInit() {
    daftarRenter.bindStream(dataC.readAllRenter(id: user.id).asyncMap((renter) {
      if (renter.length == 0) {
        change(renter, status: RxStatus.empty());
      } else {
        change(renter, status: RxStatus.success());
      }
      return renter;
    }));
    super.onInit();
  }
}
