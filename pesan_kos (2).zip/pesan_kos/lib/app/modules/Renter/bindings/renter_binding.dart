import 'package:get/get.dart';

import '../controllers/renter_controller.dart';

class RenterBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<RenterController>(
      () => RenterController(),
    );
  }
}
