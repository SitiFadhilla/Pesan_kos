import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';

class StorageController extends GetxController {
  static StorageController get instance => Get.find();
  final _storageInstance = FirebaseStorage.instance.ref();

  Future<List<String>> uploadKosImage(
      {required UserModel model,
      required String kosName,
      required List<String> imageList}) async {
    List<String> imageUrls = [];
    for (var image in imageList) {
      File gambar = File(image);
      var kosImageRef = _storageInstance.child(
          'images/products/${model.name! + model.id}/$kosName/images/image${imageList.indexOf(image)}');

      await kosImageRef.putFile(gambar).then(
        (task) {
          Rx<TaskSnapshot> uploadTask = Rx(task);
          RxDouble uploadProgress = RxDouble(
              uploadTask.value.bytesTransferred / uploadTask.value.totalBytes);

          Get.defaultDialog(
            title: "Uploading",
            content: Obx(
              () => LinearProgressIndicator(
                value: uploadProgress.value,
              ),
            ),
          );
          return task;
        },
      ).whenComplete(
        () async {
          imageUrls.add(await kosImageRef.getDownloadURL());
          if (Get.isDialogOpen!) {
            Get.back();
          }
        },
      );
    }

    return imageUrls;
  }

  Future<String> uploadBuktiTransfer(
      {required String id, required String name, required File file}) async {
    var buktiRef =
        _storageInstance.child('images/bukti_transfer/$name/${id + name}');
    var downloadLink = "";
    await buktiRef.putFile(file).then(
      (task) {
        Rx<TaskSnapshot> uploadTask = Rx(task);
        RxDouble uploadProgress = RxDouble(
            uploadTask.value.bytesTransferred / uploadTask.value.totalBytes);

        Get.defaultDialog(
          title: "Uploading",
          content: Obx(
            () => LinearProgressIndicator(
              value: uploadProgress.value,
            ),
          ),
        );
        return task;
      },
    ).whenComplete(
      () async {
        downloadLink = await buktiRef.getDownloadURL();
        if (Get.isDialogOpen!) {
          Get.back();
        }
      },
    );

    return downloadLink;
  }
}
