import 'dart:io';

import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:pesan_kos/app/data/model/bookModel.dart';
import 'package:pesan_kos/app/data/model/chatModel.dart';
import 'package:pesan_kos/app/data/model/chatRoomModel.dart';
import 'package:pesan_kos/app/data/model/kosModel.dart';
import 'package:pesan_kos/app/data/model/paymentModel.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';

import 'package:intl/intl.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';

class FirestoreController extends GetxController {
  static FirestoreController get instance => Get.find();

  final _userStore = FirebaseFirestore.instance.collection("user");
  final _kosStore = FirebaseFirestore.instance.collection("kos");
  final _chatStore = FirebaseFirestore.instance.collection("chat");

  ///
  /// USER SESSION, Sesi ini menyangkut database user di firestore
  ///

  Future createUser({required String id, required UserModel model}) async {
    await _userStore.doc(id).set(model.toMap());
  }

  // update token notification user, setiap login atau register
  Future updateToken({required String id, required String token}) async {
    await _userStore.doc(id).update({"token": token});
  }

  // Baca kos yang disewakan
  Stream<List<KosModel>> readMyKos({required String id}) {
    return _userStore.doc(id).collection("myKost").snapshots().map(
      (kosts) {
        List<KosModel> daftarKos = [];
        for (var kos in kosts.docs) {
          daftarKos.add(KosModel.fromMap(kos.data()));
        }
        return daftarKos;
      },
    );
  }

  // Read user info dari database
  Stream<UserModel> readUser({required String id}) {
    return _userStore.doc(id).snapshots().map(
          (value) => UserModel.fromMap(value.data() as Map<String, dynamic>),
        );
  }

  Stream<List<KosModel>> streamFavourite({required String userId}) {
    return _userStore.doc(userId).collection('favourite').snapshots().map(
      (books) {
        List<KosModel> daftarKos = [];
        books.docs.forEach(
          (kos) {
            daftarKos.add(KosModel.fromMap(kos.data() as Map<String, dynamic>));
          },
        );
        return daftarKos;
      },
    );
  }

  Future<bool> readKosFavourite(
      {required String userId, required String kosId}) async {
    try {
      var references =
          await _userStore.doc(userId).collection('favourite').doc(kosId).get();

      return references.exists;
    } catch (e) {}
    return false;
  }

  Future addKosFavourite(
      {required String userId,
      required String KosId,
      required KosModel kos}) async {
    await _userStore
        .doc(userId)
        .collection('favourite')
        .doc(KosId)
        .set(kos.toMap());
    Get.snackbar('Kos disimpan',
        '${GetUtils.capitalize(kos.kosName)} berhasil disimpan');
  }

  Future deleteKosFavourite(
      {required String userId, required String kosId}) async {
    await _userStore.doc(userId).collection('favourite').doc(kosId).delete();

    Get.snackbar('Kos dihapus', 'Berhasil dihapus dari favourite');
  }

  ///
  /// Kos Session
  ///

  Future createKos(
      {required KosModel model,
      required String userId,
      required String kostId}) async {
    await _userStore
        .doc(userId)
        .collection("myKost")
        .doc(kostId)
        .set(model.toMap());

    await _kosStore.doc(kostId).set(model.toMap());
  }

  Future editKos(
      {required KosModel model,
      required String userId,
      required String kostId}) async {
    await _userStore
        .doc(userId)
        .collection("myKost")
        .doc(kostId)
        .update(model.toMap());

    await _kosStore.doc(kostId).update(model.toMap()); 
  }

  Stream<List<KosModel>> readAllKos() {
    return _kosStore.snapshots().map(
      (kosList) {
        List<KosModel> daftarkos = [];
        for (var kos in kosList.docs) {
          daftarkos.add(
            KosModel.fromMap(kos.data() as Map<String, dynamic>),
          );
        }
        return daftarkos;
      },
    );
  }

  Future addBooker(
      {required String ownerId,
      required PaymentModel paymentModel,
      required String userId}) async {
    await _userStore
        .doc(ownerId)
        .collection("booking")
        .doc(paymentModel.id)
        .set(
          paymentModel.toMap(),
        );

    await _userStore.doc(userId).collection("booking").doc(paymentModel.id).set(
          paymentModel.toMap(),
        );
  }

  Stream<List<PaymentModel>> readAllBooking({required String id}) {
    return _userStore.doc(id).collection("booking").snapshots().map(
      (payments) {
        List<PaymentModel> daftarBooking = [];
        payments.docs.forEach(
          (payment) {
            daftarBooking.add(
                PaymentModel.fromMap(payment.data() as Map<String, dynamic>));
          },
        );
        return daftarBooking;
      },
    );
  }

  Future deleteBooking(
      {required String ownerId,
      required PaymentModel paymentModel,
      required String userId}) async {
    await _userStore
        .doc(ownerId)
        .collection("booking")
        .doc(paymentModel.id)
        .delete();

    await _userStore
        .doc(userId)
        .collection("booking")
        .doc(paymentModel.id)
        .delete();
  }

  Future addRenter(
      {required String ownerId,
      required PaymentModel paymentModel,
      required BookModel bookedModel,
      required String userId,
      required int value}) async {
    await _userStore.doc(ownerId).collection("renter").doc(paymentModel.id).set(
          paymentModel.toMap(),
        );

    await _kosStore.doc(bookedModel.kosId).update({"availableRoom": value});
    await _userStore
        .doc(ownerId)
        .collection("myKost")
        .doc(bookedModel.kosId)
        .update({"availableRoom": value});

    await _userStore
        .doc(userId)
        .collection("booked")
        .doc(bookedModel.kosId)
        .set(
          bookedModel.toMap(),
        );
  }

  Stream<List<BookModel>> readBookedKos({required String id}) {
    return _userStore.doc(id).collection("booked").snapshots().map(
      (payments) {
        List<BookModel> daftarBooking = [];
        payments.docs.forEach(
          (booked) {
            daftarBooking
                .add(BookModel.fromMap(booked.data() as Map<String, dynamic>));
          },
        );
        return daftarBooking;
      },
    );
  }

  Stream<List<PaymentModel>> readAllRenter({required String id}) {
    return _userStore.doc(id).collection("renter").snapshots().map(
      (payments) {
        List<PaymentModel> daftarBooking = [];
        payments.docs.forEach(
          (payment) {
            daftarBooking.add(
                PaymentModel.fromMap(payment.data() as Map<String, dynamic>));
          },
        );
        return daftarBooking;
      },
    );
  }

  Future deleteKos({required String userId, required String kostId}) async {
    await _userStore.doc(userId).collection("myKost").doc(kostId).delete();

    await _kosStore.doc(kostId).delete();
  }

  // Create Invoice, not from database
  Future<File> createInvoicePDF(PaymentModel model) async {
    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a6,
        build: (context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text("PEMESAN : ${model.bookerName}"),
              pw.SizedBox(height: 30),
              // THIS IS TABLE FOR SHOWING ORDER ITEMS
              pw.Table(
                // THIS IS FOR TABLE BORDER

                border: pw.TableBorder(
                  horizontalInside: pw.BorderSide(
                    color: PdfColor.fromHex("#000000"),
                  ),
                  bottom: pw.BorderSide(
                    color: PdfColor.fromHex("#000000"),
                  ),
                  verticalInside: pw.BorderSide(
                    color: PdfColor.fromHex("#000000"),
                  ),
                  left: pw.BorderSide(
                    color: PdfColor.fromHex("#000000"),
                  ),
                  right: pw.BorderSide(
                    color: PdfColor.fromHex("#000000"),
                  ),
                  top: pw.BorderSide(
                    color: PdfColor.fromHex("#000000"),
                  ),
                ),
              ),
              pw.SizedBox(height: 5),
              pw.Table(
                children: [
                  pw.TableRow(
                    children: [
                      pw.Text("Nama kos"),
                      pw.Text(model.kostName.toString()),
                    ],
                  ),
                  pw.TableRow(
                    children: [
                      pw.Text("Biaya"),
                      pw.Text(
                          "${NumberFormat.currency(locale: "id_ID", name: "ID", symbol: "IDR").format(model.price)}"),
                    ],
                  ),
                  pw.TableRow(
                    children: [
                      pw.Text("Durasi"),
                      pw.Text(
                          "Durasi sewa ${model.bookedKos.bookDuration} bulan"),
                    ],
                  ),
                ],
              ),
              pw.SizedBox(height: 5),
            ],
          );
        },
      ),
    );

    final output = await getApplicationDocumentsDirectory();
    final file = File(
        "${output.path}/invoice_${model.kostName}_${model.bookerName}_${DateTime.now()}.pdf");
    if (await file.exists()) {
      file.delete();
    }
    final bytes = await pdf.save();
    await file.writeAsBytes(bytes);

    if (await Permission.manageExternalStorage.request().isGranted) {
      OpenResult a = await OpenFile.open(file.path);
      print(a.type);
    }

    return file;
  }

  Future<File> printPaymentPDF(BookModel model) async {
    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a6,
        build: (context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text("PEMESAN : ${model.bookerName}"),
              pw.SizedBox(height: 30),
              // THIS IS TABLE FOR SHOWING ORDER ITEMS
              pw.Table(
                // THIS IS FOR TABLE BORDER

                border: pw.TableBorder(
                  horizontalInside: pw.BorderSide(
                    color: PdfColor.fromHex("#000000"),
                  ),
                  bottom: pw.BorderSide(
                    color: PdfColor.fromHex("#000000"),
                  ),
                  verticalInside: pw.BorderSide(
                    color: PdfColor.fromHex("#000000"),
                  ),
                  left: pw.BorderSide(
                    color: PdfColor.fromHex("#000000"),
                  ),
                  right: pw.BorderSide(
                    color: PdfColor.fromHex("#000000"),
                  ),
                  top: pw.BorderSide(
                    color: PdfColor.fromHex("#000000"),
                  ),
                ),
              ),
              pw.SizedBox(height: 5),
              pw.Table(
                children: [
                  pw.TableRow(
                    children: [
                      pw.Text("Nama kos"),
                      pw.Text(model.bookedKos.kosName.toString()),
                    ],
                  ),
                  pw.TableRow(
                    children: [
                      pw.Text("Biaya"),
                      pw.Text(
                          "${NumberFormat.currency(locale: "id_ID", name: "ID", symbol: "IDR").format(model.price)}"),
                    ],
                  ),
                  pw.TableRow(
                    children: [
                      pw.Text("Durasi"),
                      pw.Text("Durasi sewa ${model.bookDuration} bulan"),
                    ],
                  ),
                ],
              ),
              pw.SizedBox(height: 5),
            ],
          );
        },
      ),
    );

    final output = await getApplicationDocumentsDirectory();
    final file = File(
        "${output.path}/invoice_${model.bookedKos.kosName}_${model.bookerName}_${DateTime.now()}.pdf");
    if (await file.exists()) {
      file.delete();
    }
    final bytes = await pdf.save();
    await file.writeAsBytes(bytes);

    if (await Permission.manageExternalStorage.request().isGranted) {
      OpenResult a = await OpenFile.open(file.path);
      print(a.type);
    }

    return file;
  }

  // Chat session

  Stream<List<ChatRoom>> streamChatRoom() {
    return _chatStore.snapshots().map(
      (chatQuery) {
        List<ChatRoom> models = [];
        chatQuery.docs.forEach(
          (chats) {
            ChatRoom chatRoom =
                ChatRoom.fromMap(chats.data() as Map<String, dynamic>);
            models.add(chatRoom);
          },
        );

        return models;
      },
    );
  }

  Stream<List<ChatModel>> streamChatContent(
      {required String userId, required String targetId}) {
    return _chatStore
        .doc('$userId+${targetId}_chatroom')
        .collection('chats')
        .snapshots()
        .map(
      (chatQuery) {
        List<ChatModel> models = [];
        chatQuery.docs.forEach(
          (chats) {
            ChatModel chat =
                ChatModel.fromMap(chats.data() as Map<String, dynamic>);
            models.add(chat);
          },
        );

        return models;
      },
    );
  }

  Future<DocumentSnapshot> readRoomInfo(
      {required String userId, required String targetId}) async {
    return await _chatStore.doc('$userId+${targetId}_chatroom').get();
  }

  Future addRoomInfo(
      {required String userId,
      required String targetId,
      required Map<String, dynamic> room}) async {
    await _chatStore.doc('$userId+${targetId}_chatroom').set(room);
  }

  Future addChatContent(
      {required String roomId, required Map<String, dynamic> chats}) async {
    var references = _chatStore.doc(roomId).collection('chats');

    references.add(chats);
  }
}
