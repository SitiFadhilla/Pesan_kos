import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:pesan_kos/app/data/model/dialogModel.dart';

class AuthController extends GetxController {
  static AuthController get instance => Get.find();
  final _instance = FirebaseAuth.instance;
  Rx<User?> get currentUser => Rx(_instance.currentUser);

  Future<UserCredential?> logInUser(
      {required String email, required String password}) async {
    try {
      return await _instance.signInWithEmailAndPassword(
          email: email, password: password);
    } catch (e) {
      DialogModel.ErrorDialog(e.toString());
    }
  }

  Future<UserCredential?> signUpUser(
      {required String email, required String password}) async {
    try {
      return await _instance.createUserWithEmailAndPassword(
          email: email, password: password);
    } catch (e) {
      DialogModel.ErrorDialog(e.toString());
    }
  }

  Future logOut() async {
    await _instance.signOut();
  }

  Future forgotPassword({required String email}) async {
    await _instance.sendPasswordResetEmail(email: email);
  }

  @override
  void onInit() {
    currentUser.bindStream(_instance.authStateChanges());
    super.onInit();
  }
}
