import 'package:get/get.dart';
import 'package:pesan_kos/app/controllers/auth_controller.dart';
import 'package:pesan_kos/app/controllers/firestore_controller.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';

class UserModelController extends GetxController {
  static UserModelController get instance => Get.find();
  final dataC = FirestoreController.instance;
  final authC = AuthController.instance;

  Rxn<UserModel> userModel = Rxn();

  @override
  void onInit() {
    userModel.bindStream(dataC.readUser(id: authC.currentUser.value!.uid));
    super.onInit();
  }
}
