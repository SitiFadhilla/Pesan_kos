// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

import 'package:flutter/foundation.dart';

class KosModel {
  String id;
  String kosName;
  int price;
  String location;
  String description;
  List facilities;
  int roomType;
  List image;
  int availableRoom;
  double? rating;
  String ownerId;
  KosModel({
    required this.id,
    required this.kosName,
    required this.price,
    required this.location,
    required this.description,
    required this.facilities,
    required this.roomType,
    required this.image,
    required this.availableRoom,
    this.rating,
    required this.ownerId,
  });

  KosModel copyWith({
    String? id,
    String? kosName,
    int? price,
    String? location,
    String? description,
    List? facilities,
    int? roomType,
    List? image,
    int? availableRoom,
    double? rating,
    String? ownerId,
  }) {
    return KosModel(
      id: id ?? this.id,
      kosName: kosName ?? this.kosName,
      price: price ?? this.price,
      location: location ?? this.location,
      description: description ?? this.description,
      facilities: facilities ?? this.facilities,
      roomType: roomType ?? this.roomType,
      image: image ?? this.image,
      availableRoom: availableRoom ?? this.availableRoom,
      rating: rating ?? this.rating,
      ownerId: ownerId ?? this.ownerId,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'id': id,
      'kosName': kosName,
      'price': price,
      'location': location,
      'description': description,
      'facilities': facilities,
      'roomType': roomType,
      'image': image,
      'availableRoom': availableRoom,
      'rating': rating,
      'ownerId': ownerId,
    };
  }

  factory KosModel.fromMap(Map<String, dynamic> map) {
    return KosModel(
      id: map['id'] as String,
      kosName: map['kosName'] as String,
      price: map['price'] as int,
      location: map['location'] as String,
      description: map['description'] as String,
      facilities: List.from((map['facilities'] as List)),
      roomType: map['roomType'] as int,
      image: List.from((map['image'] as List)),
      availableRoom: map['availableRoom'] as int,
      rating: map['rating'] != null ? map['rating'] as double : null,
      ownerId: map['ownerId'] as String,
    );
  }

  String toJson() => json.encode(toMap());

  factory KosModel.fromJson(String source) =>
      KosModel.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'KosModel(id: $id, kosName: $kosName, price: $price, location: $location, description: $description, facilities: $facilities, roomType: $roomType, image: $image, availableRoom: $availableRoom, rating: $rating, ownerId: $ownerId)';
  }

  @override
  bool operator ==(covariant KosModel other) {
    if (identical(this, other)) return true;

    return other.id == id &&
        other.kosName == kosName &&
        other.price == price &&
        other.location == location &&
        other.description == description &&
        listEquals(other.facilities, facilities) &&
        other.roomType == roomType &&
        listEquals(other.image, image) &&
        other.availableRoom == availableRoom &&
        other.rating == rating &&
        other.ownerId == ownerId;
  }

  @override
  int get hashCode {
    return id.hashCode ^
        kosName.hashCode ^
        price.hashCode ^
        location.hashCode ^
        description.hashCode ^
        facilities.hashCode ^
        roomType.hashCode ^
        image.hashCode ^
        availableRoom.hashCode ^
        rating.hashCode ^
        ownerId.hashCode;
  }
}
