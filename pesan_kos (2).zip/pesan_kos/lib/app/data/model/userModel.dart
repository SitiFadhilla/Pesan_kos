// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class UserModel {
  final String id;
  final String email;
  final String? name;
  final String? image;
  final String status;
  final String token;
  final String jenisKelamin;
  final String? pekerjaan;
  UserModel({
    required this.id,
    required this.email,
    this.name,
    this.image,
    required this.status,
    required this.token,
    required this.jenisKelamin,
    this.pekerjaan,
  });

  UserModel copyWith({
    String? id,
    String? email,
    String? name,
    String? image,
    String? status,
    String? token,
    String? jenisKelamin,
    String? pekerjaan,
  }) {
    return UserModel(
      id: id ?? this.id,
      email: email ?? this.email,
      name: name ?? this.name,
      image: image ?? this.image,
      status: status ?? this.status,
      token: token ?? this.token,
      jenisKelamin: jenisKelamin ?? this.jenisKelamin,
      pekerjaan: pekerjaan ?? this.pekerjaan,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'id': id,
      'email': email,
      'name': name,
      'image': image,
      'status': status,
      'token': token,
      'jenisKelamin': jenisKelamin,
      'pekerjaan': pekerjaan,
    };
  }

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      id: map['id'] as String,
      email: map['email'] as String,
      name: map['name'] != null ? map['name'] as String : null,
      image: map['image'] != null ? map['image'] as String : null,
      status: map['status'] as String,
      token: map['token'] as String,
      jenisKelamin: map['jenisKelamin'] as String,
      pekerjaan: map['pekerjaan'] != null ? map['pekerjaan'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory UserModel.fromJson(String source) =>
      UserModel.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'UserModel(id: $id, email: $email, name: $name, image: $image, status: $status, token: $token, jenisKelamin: $jenisKelamin, pekerjaan: $pekerjaan)';
  }

  @override
  bool operator ==(covariant UserModel other) {
    if (identical(this, other)) return true;

    return other.id == id &&
        other.email == email &&
        other.name == name &&
        other.image == image &&
        other.status == status &&
        other.token == token &&
        other.jenisKelamin == jenisKelamin &&
        other.pekerjaan == pekerjaan;
  }

  @override
  int get hashCode {
    return id.hashCode ^
        email.hashCode ^
        name.hashCode ^
        image.hashCode ^
        status.hashCode ^
        token.hashCode ^
        jenisKelamin.hashCode ^
        pekerjaan.hashCode;
  }
}
