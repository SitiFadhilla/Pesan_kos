// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

import 'package:pesan_kos/app/data/model/bookModel.dart';

class PaymentModel {
  String id;
  String bookerName;
  String kostName;
  bool isPayNow;
  bool isPayed;
  double price;
  double dp;
  String bookerId;
  String ownerId;
  String kosId;
  BookModel bookedKos;
  String? buktiTransfer;
  PaymentModel({
    required this.id,
    required this.bookerName,
    required this.kostName,
    required this.isPayNow,
    required this.isPayed,
    required this.price,
    required this.dp,
    required this.bookerId,
    required this.ownerId,
    required this.kosId,
    required this.bookedKos,
    this.buktiTransfer,
  });

  PaymentModel copyWith({
    String? id,
    String? bookerName,
    String? kostName,
    bool? isPayNow,
    bool? isPayed,
    double? price,
    double? dp,
    String? bookerId,
    String? ownerId,
    String? kosId,
    BookModel? bookedKos,
    String? buktiTransfer,
  }) {
    return PaymentModel(
      id: id ?? this.id,
      bookerName: bookerName ?? this.bookerName,
      kostName: kostName ?? this.kostName,
      isPayNow: isPayNow ?? this.isPayNow,
      isPayed: isPayed ?? this.isPayed,
      price: price ?? this.price,
      dp: dp ?? this.dp,
      bookerId: bookerId ?? this.bookerId,
      ownerId: ownerId ?? this.ownerId,
      kosId: kosId ?? this.kosId,
      bookedKos: bookedKos ?? this.bookedKos,
      buktiTransfer: buktiTransfer ?? this.buktiTransfer,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'id': id,
      'bookerName': bookerName,
      'kostName': kostName,
      'isPayNow': isPayNow,
      'isPayed': isPayed,
      'price': price,
      'dp': dp,
      'bookerId': bookerId,
      'ownerId': ownerId,
      'kosId': kosId,
      'bookedKos': bookedKos.toMap(),
      'buktiTransfer': buktiTransfer,
    };
  }

  factory PaymentModel.fromMap(Map<String, dynamic> map) {
    return PaymentModel(
      id: map['id'] as String,
      bookerName: map['bookerName'] as String,
      kostName: map['kostName'] as String,
      isPayNow: map['isPayNow'] as bool,
      isPayed: map['isPayed'] as bool,
      price: map['price'] as double,
      dp: map['dp'] as double,
      bookerId: map['bookerId'] as String,
      ownerId: map['ownerId'] as String,
      kosId: map['kosId'] as String,
      bookedKos: BookModel.fromMap(map['bookedKos'] as Map<String, dynamic>),
      buktiTransfer:
          map['buktiTransfer'] != null ? map['buktiTransfer'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory PaymentModel.fromJson(String source) =>
      PaymentModel.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'PaymentModel(id: $id, bookerName: $bookerName, kostName: $kostName, isPayNow: $isPayNow, isPayed: $isPayed, price: $price, dp: $dp, bookerId: $bookerId, ownerId: $ownerId, kosId: $kosId, bookedKos: $bookedKos, buktiTransfer: $buktiTransfer)';
  }

  @override
  bool operator ==(covariant PaymentModel other) {
    if (identical(this, other)) return true;

    return other.id == id &&
        other.bookerName == bookerName &&
        other.kostName == kostName &&
        other.isPayNow == isPayNow &&
        other.isPayed == isPayed &&
        other.price == price &&
        other.dp == dp &&
        other.bookerId == bookerId &&
        other.ownerId == ownerId &&
        other.kosId == kosId &&
        other.bookedKos == bookedKos &&
        other.buktiTransfer == buktiTransfer;
  }

  @override
  int get hashCode {
    return id.hashCode ^
        bookerName.hashCode ^
        kostName.hashCode ^
        isPayNow.hashCode ^
        isPayed.hashCode ^
        price.hashCode ^
        dp.hashCode ^
        bookerId.hashCode ^
        ownerId.hashCode ^
        kosId.hashCode ^
        bookedKos.hashCode ^
        buktiTransfer.hashCode;
  }
}
