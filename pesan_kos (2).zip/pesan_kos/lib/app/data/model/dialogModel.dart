import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pesan_kos/app/data/reusable.dart';

class DialogModel {
  static ConfirmationDialog(
      {required String title,
      required String middleText,
      Function()? confirmation}) {
    return Get.defaultDialog(
        title: title,
        middleText: middleText,
        onConfirm: confirmation,
        onCancel: () {},
        textConfirm: "confirm",
        textCancel: "batal");
  }

  static ErrorDialog(e) {
    return Get.defaultDialog(
        title: "ERROR", middleText: e, onCancel: () {}, textCancel: "oke");
  }

  static buildForgotPassword(void Function()? onConfirm) {
    TextEditingController emailControler = TextEditingController();
    return Get.defaultDialog(
        title: "Lupa Password",
        content: ReusableWidget.customWidget(
          child: TextField(
            controller: emailControler,
            decoration: InputDecoration(border: InputBorder.none),
          ),
        ),
        textConfirm: "reset",
        onConfirm: onConfirm);
  }
}
