// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

import 'package:pesan_kos/app/data/model/kosModel.dart';
import 'package:pesan_kos/app/data/model/userModel.dart';

class BookModel {
  String id;
  String kosId;
  String kosName;
  String location;
  KosModel bookedKos;
  String bookerId;
  String bookerName;
  UserModel bookerModel;
  int bookDuration;
  int price;
  int quantity;
  DateTime startDay;
  DateTime endDay;
  BookModel({
    required this.id,
    required this.kosId,
    required this.kosName,
    required this.location,
    required this.bookedKos,
    required this.bookerId,
    required this.bookerName,
    required this.bookerModel,
    required this.bookDuration,
    required this.price,
    this.quantity = 1,
    required this.startDay,
    required this.endDay,
  });

  BookModel copyWith({
    String? id,
    String? kosId,
    String? kosName,
    String? location,
    KosModel? bookedKos,
    String? bookerId,
    String? bookerName,
    UserModel? bookerModel,
    int? bookDuration,
    int? price,
    int? quantity,
    DateTime? startDay,
    DateTime? endDay,
  }) {
    return BookModel(
      id: id ?? this.id,
      kosId: kosId ?? this.kosId,
      kosName: kosName ?? this.kosName,
      location: location ?? this.location,
      bookedKos: bookedKos ?? this.bookedKos,
      bookerId: bookerId ?? this.bookerId,
      bookerName: bookerName ?? this.bookerName,
      bookerModel: bookerModel ?? this.bookerModel,
      bookDuration: bookDuration ?? this.bookDuration,
      price: price ?? this.price,
      quantity: quantity ?? this.quantity,
      startDay: startDay ?? this.startDay,
      endDay: endDay ?? this.endDay,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'id': id,
      'kosId': kosId,
      'kosName': kosName,
      'location': location,
      'bookedKos': bookedKos.toMap(),
      'bookerId': bookerId,
      'bookerName': bookerName,
      'bookerModel': bookerModel.toMap(),
      'bookDuration': bookDuration,
      'price': price,
      'quantity': quantity,
      'startDay': startDay.millisecondsSinceEpoch,
      'endDay': endDay.millisecondsSinceEpoch,
    };
  }

  factory BookModel.fromMap(Map<String, dynamic> map) {
    return BookModel(
      id: map['id'] as String,
      kosId: map['kosId'] as String,
      kosName: map['kosName'] as String,
      location: map['location'] as String,
      bookedKos: KosModel.fromMap(map['bookedKos'] as Map<String, dynamic>),
      bookerId: map['bookerId'] as String,
      bookerName: map['bookerName'] as String,
      bookerModel:
          UserModel.fromMap(map['bookerModel'] as Map<String, dynamic>),
      bookDuration: map['bookDuration'] as int,
      price: map['price'] as int,
      quantity: map['quantity'] as int,
      startDay: DateTime.fromMillisecondsSinceEpoch(map['startDay'] as int),
      endDay: DateTime.fromMillisecondsSinceEpoch(map['endDay'] as int),
    );
  }

  String toJson() => json.encode(toMap());

  factory BookModel.fromJson(String source) =>
      BookModel.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'BookModel(id: $id, kosId: $kosId, kosName: $kosName, location: $location, bookedKos: $bookedKos, bookerId: $bookerId, bookerName: $bookerName, bookerModel: $bookerModel, bookDuration: $bookDuration, price: $price, quantity: $quantity, startDay: $startDay, endDay: $endDay)';
  }

  @override
  bool operator ==(covariant BookModel other) {
    if (identical(this, other)) return true;

    return other.id == id &&
        other.kosId == kosId &&
        other.kosName == kosName &&
        other.location == location &&
        other.bookedKos == bookedKos &&
        other.bookerId == bookerId &&
        other.bookerName == bookerName &&
        other.bookerModel == bookerModel &&
        other.bookDuration == bookDuration &&
        other.price == price &&
        other.quantity == quantity &&
        other.startDay == startDay &&
        other.endDay == endDay;
  }

  @override
  int get hashCode {
    return id.hashCode ^
        kosId.hashCode ^
        kosName.hashCode ^
        location.hashCode ^
        bookedKos.hashCode ^
        bookerId.hashCode ^
        bookerName.hashCode ^
        bookerModel.hashCode ^
        bookDuration.hashCode ^
        price.hashCode ^
        quantity.hashCode ^
        startDay.hashCode ^
        endDay.hashCode;
  }
}
