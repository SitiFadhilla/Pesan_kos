// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class ChatModel {
  String text;
  String senderId;
  String targetId;
  DateTime created_at;
  ChatModel({
    required this.text,
    required this.senderId,
    required this.targetId,
    required this.created_at,
  });

  ChatModel copyWith({
    String? text,
    String? senderId,
    String? targetId,
    DateTime? created_at,
  }) {
    return ChatModel(
      text: text ?? this.text,
      senderId: senderId ?? this.senderId,
      targetId: targetId ?? this.targetId,
      created_at: created_at ?? this.created_at,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'text': text,
      'senderId': senderId,
      'targetId': targetId,
      'created_at': created_at.millisecondsSinceEpoch,
    };
  }

  factory ChatModel.fromMap(Map<String, dynamic> map) {
    return ChatModel(
      text: map['text'] as String,
      senderId: map['senderId'] as String,
      targetId: map['targetId'] as String,
      created_at: DateTime.fromMillisecondsSinceEpoch(map['created_at'] as int),
    );
  }

  String toJson() => json.encode(toMap());

  factory ChatModel.fromJson(String source) =>
      ChatModel.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'ChatModel(text: $text, senderId: $senderId, targetId: $targetId, created_at: $created_at)';
  }

  @override
  bool operator ==(covariant ChatModel other) {
    if (identical(this, other)) return true;

    return other.text == text &&
        other.senderId == senderId &&
        other.targetId == targetId &&
        other.created_at == created_at;
  }

  @override
  int get hashCode {
    return text.hashCode ^
        senderId.hashCode ^
        targetId.hashCode ^
        created_at.hashCode;
  }
}
