// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class ChatRoom {
  String creatorId;
  String targetId;
  String roomName;
  String targetRoomName;
  DateTime created_at;
  String id;
  ChatRoom(
      {required this.creatorId,
      required this.targetId,
      required this.roomName,
      required this.created_at,
      required this.id,
      required this.targetRoomName});

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'creatorId': creatorId,
      'targetId': targetId,
      'roomName': roomName,
      'created_at': created_at.millisecondsSinceEpoch,
      'id': id,
      'targetRoomName': targetRoomName
    };
  }

  factory ChatRoom.fromMap(Map<String, dynamic> map) {
    return ChatRoom(
        creatorId: map['creatorId'] as String,
        targetId: map['targetId'] as String,
        roomName: map['roomName'] as String,
        created_at:
            DateTime.fromMillisecondsSinceEpoch(map['created_at'] as int),
        id: map['id'],
        targetRoomName: map['targetRoomName']);
  }

  String toJson() => json.encode(toMap());

  factory ChatRoom.fromJson(String source) =>
      ChatRoom.fromMap(json.decode(source) as Map<String, dynamic>);
}
