import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pesan_kos/app/data/model/kosModel.dart';

class ReusableWidget {
  static final summerPrimary = Color(0xff0A4D68);
  static final summerPrice = Color(0xff558776);

  static Text customTitleWidget({required String data}) {
    return Text(
      data,
      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30),
      textAlign: TextAlign.center,
    );
  }

  static Widget customTextFormField(
      {required TextEditingController textEditingController,
      required String label,
      required String hint,
      required TextInputType inputType,
      String? Function(String? value)? validator,
      required Rx<bool> isObscured,
      bool enableIcon = false,
      int maxLine = 1,
      int minLine = 1,
      bool useBorder = false}) {
    return Obx(
      () => TextFormField(
        controller: textEditingController,
        validator: validator,
        obscureText: isObscured.value,
        maxLines: maxLine,
        minLines: minLine,
        keyboardType: inputType,
        decoration: InputDecoration(
          focusedBorder: (useBorder)
              ? OutlineInputBorder(borderRadius: BorderRadius.circular(10))
              : null,
          border: (useBorder)
              ? OutlineInputBorder(
                  borderSide: BorderSide(color: Get.theme.primaryColor),
                )
              : InputBorder.none,
          labelText: label,
          hintText: hint,
          suffixIcon: (enableIcon)
              ? IconButton(
                  onPressed: () {
                    isObscured.toggle();
                  },
                  icon: Obx(
                    () => Icon((isObscured.value)
                        ? Icons.visibility_off
                        : Icons.visibility),
                  ),
                )
              : null,
        ),
      ),
    );
  }

  static Widget customWidget(
      {required Widget child,
      bool isAvatar = false,
      double padding = 8,
      Function()? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: (!isAvatar) ? EdgeInsets.all(padding) : null,
        decoration: BoxDecoration(
          shape: (isAvatar) ? BoxShape.circle : BoxShape.rectangle,
          color: Colors.white,
          border: Border.all(
            color: summerPrimary,
            width: 3,
          ),
          borderRadius: (isAvatar) ? null : BorderRadius.circular(25),
          boxShadow: [
            BoxShadow(
              color: summerPrimary,
              offset: Offset(2, 2),
              spreadRadius: 1,
            ),
          ],
        ),
        child: child,
      ),
    );
  }

  static Widget retroButton({required String child, Function()? onTap}) {
    return ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        backgroundColor: summerPrimary,
        elevation: 6,
      ),
      child: Text(
        child,
        style: TextStyle(color: Colors.white),
      ),
    );
  }

  static AppBar customAppBar(String title, {List<Widget>? actions}) {
    return AppBar(
      title: Text(
        title,
        style: TextStyle(fontWeight: FontWeight.bold, color: summerPrimary),
      ),
      actions: actions,
      surfaceTintColor: Colors.transparent,
    );
  }

  static Widget kosCard({
    required KosModel model,
    Function()? onTap,
    Function()? favOnTap,
    required String status,
  }) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: GestureDetector(
        onTap: onTap,
        child: Card(
          color: Colors.white,
          elevation: 3,
          clipBehavior: Clip.antiAliasWithSaveLayer,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          child: Container(
            height: 280,
            width: 300,
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              image: DecorationImage(
                  image: CachedNetworkImageProvider(
                    model.image[0],
                  ),
                  fit: BoxFit.cover),
            ),
            child: Stack(
              children: [
                // Title and Location
                Positioned(
                  top: 200,
                  child: ConstrainedBox(
                    constraints: BoxConstraints(maxWidth: 250),
                    child: Card(
                      color: Colors.white.withOpacity(0.7),
                      elevation: 0,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              model.kosName,
                              style: TextStyle(
                                color: summerPrimary,
                                fontWeight: FontWeight.bold,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text(
                              model.location,
                              style: TextStyle(
                                color: summerPrimary,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                if (status != "OWNER")
                  Positioned(
                    left: 220,
                    child: Card(
                      color: Colors.white.withOpacity(0.7),
                      child: IconButton(
                        onPressed: favOnTap,
                        icon: Icon(
                          Icons.favorite_outline,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  )
              ],
            ),
          ),
        ),
      ),
    );
  }

  static TextStyle priceStyle() {
    return TextStyle(
        fontSize: 17, color: summerPrimary, fontWeight: FontWeight.bold);
  }
}
