import 'package:get/get.dart';

class FcmApiProvider extends GetConnect {
  final String fcmUrl = 'https://fcm.googleapis.com/fcm/send';
  final fcmKey =
      "AAAABzMA_js:APA91bGwNw7TjD_OhOYwihKFJcxdHfp1bwyMK-niBINRcY7HWq3zfZEfCN22CJ6qCZzzx6bQLQSo6lMIVDArNWUU8DWtsAy4nBc_nWjNnVZ7Ntg3BlZai8oUQClZvV5YvLCOwi4Hjkpn";
  Future<Response> sendOrder(
      {required String title,
      required String body,
      required String fcmToken}) async {
    var headers = {
      'Content-Type': 'application/json',
      'Authorization': 'key=$fcmKey'
    };
    var data = {
      "to": "$fcmToken",
      "priority": "high",
      "notification": {
        "title": "$title",
        "body": "$body",
        "sound": "default",
        "channel_id": "order"
      }
    };

    return post(fcmUrl, data, headers: headers);
  }
}
