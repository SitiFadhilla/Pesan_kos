import 'package:get/get.dart';
import 'package:pesan_kos/app/modules/PostKos/views/post_kos_edit.dart';

import '../modules/BookingList/bindings/booking_list_binding.dart';
import '../modules/BookingList/views/booking_list_view.dart';
import '../modules/ChatList/bindings/chat_list_binding.dart';
import '../modules/ChatList/views/chat_list_view.dart';
import '../modules/ChatRoom/bindings/chat_room_binding.dart';
import '../modules/ChatRoom/views/chat_room_view.dart';
import '../modules/DetailKos/bindings/detail_kos_binding.dart';
import '../modules/DetailKos/views/detail_kos_view.dart';
import '../modules/Favourite/bindings/favourite_binding.dart';
import '../modules/Favourite/views/favourite_view.dart';
import '../modules/KosSewa/bindings/kos_sewa_binding.dart';
import '../modules/KosSewa/views/kos_sewa_view.dart';
import '../modules/Login/bindings/login_binding.dart';
import '../modules/Login/views/login_view.dart';
import '../modules/PayNow/bindings/pay_now_binding.dart';
import '../modules/PayNow/views/pay_now_view.dart';
import '../modules/Payment/bindings/payment_binding.dart';
import '../modules/Payment/views/payment_view.dart';
import '../modules/PesanKos/bindings/pesan_kos_binding.dart';
import '../modules/PesanKos/views/pesan_kos_view.dart';
import '../modules/PostKos/bindings/post_kos_binding.dart';
import '../modules/PostKos/views/post_kos_view.dart';
import '../modules/Profile/bindings/profile_binding.dart';
import '../modules/Profile/views/profile_view.dart';
import '../modules/RentedKos/bindings/rented_kos_binding.dart';
import '../modules/RentedKos/views/rented_kos_view.dart';
import '../modules/Renter/bindings/renter_binding.dart';
import '../modules/Renter/views/renter_view.dart';
import '../modules/SignUp/bindings/sign_up_binding.dart';
import '../modules/SignUp/views/sign_up_view.dart';
import '../modules/home/bindings/home_binding.dart';
import '../modules/home/views/home_view.dart';

part 'app_routes.dart';

class AppPages {
  AppPages._();

  static const INITIAL = Routes.HOME;
  static const LOGIN = Routes.LOGIN;

  static final routes = [
    GetPage(
      name: _Paths.HOME,
      page: () => HomeView(),
      binding: HomeBinding(),
    ),
    GetPage(
      name: _Paths.LOGIN,
      page: () => const LoginView(),
      binding: LoginBinding(),
    ),
    GetPage(
      name: _Paths.SIGN_UP,
      page: () => const SignUpView(),
      binding: SignUpBinding(),
    ),
    GetPage(
      name: _Paths.PROFILE,
      page: () => const ProfileView(),
      binding: ProfileBinding(),
    ),
    GetPage(
      name: _Paths.RENTED_KOS,
      page: () => const RentedKosView(),
      binding: RentedKosBinding(),
    ),
    GetPage(
      name: _Paths.POST_KOS,
      page: () => const PostKosView(),
      binding: PostKosBinding(),
    ),
    GetPage(
      name: _Paths.DETAIL_KOS,
      page: () => const DetailKosView(),
      binding: DetailKosBinding(),
    ),
    GetPage(
      name: _Paths.PESAN_KOS,
      page: () => const PesanKosView(),
      binding: PesanKosBinding(),
    ),
    GetPage(
      name: _Paths.PAYMENT,
      page: () => const PaymentView(),
      binding: PaymentBinding(),
    ),
    GetPage(
      name: _Paths.BOOKING_LIST,
      page: () => const BookingListView(),
      binding: BookingListBinding(),
    ),
    GetPage(
      name: _Paths.KOS_SEWA,
      page: () => const KosSewaView(),
      binding: KosSewaBinding(),
    ),
    GetPage(
      name: _Paths.RENTER,
      page: () => const RenterView(),
      binding: RenterBinding(),
    ),
    GetPage(
      name: _Paths.PAY_NOW,
      page: () => const PayNowView(),
      binding: PayNowBinding(),
    ),
    GetPage(
      name: _Paths.FAVOURITE,
      page: () => const FavouriteView(),
      binding: FavouriteBinding(),
    ),
    GetPage(
      name: _Paths.CHAT_ROOM,
      page: () => ChatRoomView(),
      binding: ChatRoomBinding(),
    ),
    GetPage(
      name: _Paths.CHAT_LIST,
      page: () => const ChatListView(),
      binding: ChatListBinding(),
    ),
    GetPage(
      name: _Paths.EDIT_KOS,
      page: () => const EditKos(),
      binding: PostKosBinding(),
    ),
  ];
}
