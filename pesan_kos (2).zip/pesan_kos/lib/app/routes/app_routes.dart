part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();
  static const HOME = _Paths.HOME;
  static const LOGIN = _Paths.LOGIN;
  static const SIGN_UP = _Paths.SIGN_UP;
  static const PROFILE = _Paths.PROFILE;
  static const RENTED_KOS = _Paths.RENTED_KOS;
  static const POST_KOS = _Paths.POST_KOS;
  static const DETAIL_KOS = _Paths.DETAIL_KOS;
  static const PESAN_KOS = _Paths.PESAN_KOS;
  static const PAYMENT = _Paths.PAYMENT;
  static const BOOKING_LIST = _Paths.BOOKING_LIST;
  static const KOS_SEWA = _Paths.KOS_SEWA;
  static const RENTER = _Paths.RENTER;
  static const PAY_NOW = _Paths.PAY_NOW;
  static const FAVOURITE = _Paths.FAVOURITE;
  static const CHAT_ROOM = _Paths.CHAT_ROOM;
  static const CHAT_LIST = _Paths.CHAT_LIST;
  static const EDIT_KOS = _Paths.EDIT_KOS;
}

abstract class _Paths {
  _Paths._();
  static const HOME = '/home';
  static const LOGIN = '/login';
  static const SIGN_UP = '/sign-up';
  static const PROFILE = '/profile';
  static const RENTED_KOS = '/rented-kos';
  static const POST_KOS = '/post-kos';
  static const DETAIL_KOS = '/detail-kos';
  static const PESAN_KOS = '/pesan-kos';
  static const PAYMENT = '/payment';
  static const BOOKING_LIST = '/booking-list';
  static const KOS_SEWA = '/kos-sewa';
  static const RENTER = '/renter';
  static const PAY_NOW = '/pay-now';
  static const FAVOURITE = '/favourite';
  static const CHAT_ROOM = '/chat-room';
  static const CHAT_LIST = '/chat-list';
  static const EDIT_KOS = '/edit-kos';
}
