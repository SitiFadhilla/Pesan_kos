package com.anotherguy.pesankos.pesan_kos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
